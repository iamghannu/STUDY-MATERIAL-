/**
 * 
 */
package PAYTM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * @author pvyavaha
 *
 *
 *
 *This class will contain all the locators and element of login page
 */
public class LogIn_Page {
	
	WebDriver driver;
	By username= By.id("input_0");
	By password= By.id("input_1");
	By login_butt= By.id("loginForm");
	By Forgot_Password= By.xpath("//a[@event-action='forgot_password_clicked']");
    By Other_login_issue= By.xpath("//a[@event-action='other_login_issues_clicked']");
    
    public LogIn_Page(WebDriver driver)
    {
    	this.driver= driver;
    }
    public void username(String mob_no) {
    	driver.findElement(username).sendKeys(mob_no);
    }
    public void password(String pass) {
    	driver.findElement( password).sendKeys(pass);
    	
    }
    
    public void  login_butt() {
    	driver.findElement(login_butt).click();
    	
    }
    public void  Forgot_Password() {
    	driver.findElement(Forgot_Password).click();
    	
    }
    public void Other_login_issue() {
    	driver.findElement(Other_login_issue).click();
    	
    }
}

