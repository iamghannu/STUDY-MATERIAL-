package PAYTM;

import java.util.concurrent.TimeUnit;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginusingPOM {

	
	@Test
	
	public void verifyLogIn() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",  "D:\\Users\\pvyavaha\\Downloads\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://paytm.com/");
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 driver.findElement(By.className("_3ac-")).click();
		 Thread.sleep(8000);
		 driver.switchTo().frame(0);
		 LogIn_Page e= new LogIn_Page(driver);
		 e.username("8016038247");
		 e.password("23041994");
		 e.login_butt();
		 driver.quit();
		 
	}
}
