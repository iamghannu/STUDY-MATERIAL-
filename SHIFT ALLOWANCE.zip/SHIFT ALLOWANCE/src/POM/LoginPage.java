/**
 * 
 */
package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * @author ghagarwa
 * It contains all the elements present in LOG IN page of SHIFT ALLOWANCE application
 * The only purpose of using Page Factory is so that i can use CACHE LOOK UP to increase the performance efficiency
 */
public class LoginPage {
	
	WebDriver driver;
	
	public LoginPage(WebDriver driver)
	{
		this.driver= driver;
	}
	
	@FindBy(id="UserId") WebElement username;
	
	@FindBy(how = How.XPATH, using="//input[@name='txtpwd']") WebElement Password;
	
	
	@FindBy(id="btnLogin") WebElement Login_Butt;
	
 
	public void LogIn(String uid, String pass)
	{
		username.sendKeys(uid);
		Password.sendKeys(pass);
		Login_Butt.click();
}
}

