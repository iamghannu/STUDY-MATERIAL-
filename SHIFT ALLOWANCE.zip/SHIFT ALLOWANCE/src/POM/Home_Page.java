/**
 * 
 */
package POM;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * @author ghagarwa
 *
 */
public class Home_Page {
	
	WebDriver driver;
	
	public Home_Page(WebDriver driver)
	{
		this.driver= driver;
	}
	
	@FindBy(how = How.LINK_TEXT, using="Home") WebElement Home_Butt;
	
	@FindBy(how = How.LINK_TEXT, using="Shift") WebElement Shift_Butt;
	
	@FindBy(how = How.LINK_TEXT, using="Shift User Manual") WebElement Shift_User_Manual;
	
	@FindBy(how = How.LINK_TEXT, using="FAQ") WebElement FAQ;
	
	@FindBy(how = How.LINK_TEXT, using="Process Document") WebElement Process_Document;
	
	@FindBy(how = How.LINK_TEXT, using="Policy Document") WebElement Policy_Document ;
	
	@FindBy(how = How.LINK_TEXT, using="On-call allowance Policy Document ") WebElement On_call_allowance_Policy_Document  ;
	
	@FindBy(how = How.XPATH, using="//a[text()='Log Off']") WebElement Log_Off ;
	
	@FindBy(how = How.XPATH, using="//*[@id='cssmenu']/ul/li//span[text()=' Approvals ']") WebElement Approvals ;

	
	public void Home()
	{
		Home_Butt.click();
	}
	
	public void Shift() throws InterruptedException
	{
		
		Actions actions = new Actions(driver);
		actions.moveToElement(Shift_Butt).click();
		actions.sendKeys(Keys.chord(Keys.TAB)).sendKeys(Keys.ENTER).perform();;
		
		 
	}
	
	public void UserManual()
	{
		Shift_User_Manual.click();
	}
	
	public void Questions()
	{
		FAQ.click();
	}
	
	public void ProcessDoc()
	{
		Process_Document.click();
	}
	
	public void PolicyDoc()
	{
		Policy_Document.click();
		
	}
	
	public void OnCallDoc()
	{
		On_call_allowance_Policy_Document.click();
	}
	
	public void LogOff()
	{
		Log_Off.click();
	}
	public void ApprovalBySupervisor()
	{
		Actions actions = new Actions(driver);
		actions.moveToElement(Approvals).click();
		actions.sendKeys(Keys.chord(Keys.TAB)).sendKeys(Keys.ENTER).perform();
	}
	
	public void ApprovalByProjectManager()
	{
		Actions actions = new Actions(driver);
		actions.moveToElement(Approvals).click();
		actions.sendKeys(Keys.chord(Keys.TAB));
		actions.sendKeys(Keys.chord(Keys.TAB)).sendKeys(Keys.ENTER).perform();
	}
}
