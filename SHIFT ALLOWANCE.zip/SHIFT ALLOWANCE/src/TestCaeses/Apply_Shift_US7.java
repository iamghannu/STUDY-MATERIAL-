/**
 * 
 */
package TestCaeses;


import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;                                                                                                                                                                  

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;












import java.io.IOException;












































import HELPER.BrowserFactory;
import HELPER.DB_Operation;
import HELPER.ExcelDataConfig;
import HELPER.Screenshot;
import POM.Home_Page;
import POM.LoginPage;

/**
 * @author ghagarwa
 *
 */

@Listeners(HELPER.TestNGListener.class)
public class Apply_Shift_US7 {
	
	String xpathmonth=null;
	 String totaldays=null;
	String MonthToBeChecked=null;
	String MonthToBeClicked=null;

	ExtentReports report = new ExtentReports("D:\\Shift Allowance\\AUTOMATION\\US7\\Reports\\Apply_Shift.html");    //Creating Object Of class 
	ExtentTest logger;
	String LOCATION="D:\\Shift Allowance\\AUTOMATION\\US7\\SCREENSHOTS\\";
	public  WebDriver driver;   //creating Global Variable
    String FirstMonth;
    String  SecondMonth;
    String ThirdMonth;
   String LogInExcelPath="D:\\Shift Allowance\\AUTOMATION\\US8_AUTOMATION_LOGIN CREDENTIALS_DATA DRIVEN.xlsx";
   DB_Operation DB= new DB_Operation();
   String EmpulseDataPath= "D:\\Shift Allowance\\TEST DATA\\US9_TC4_REGRESSION TESTING_DATA CREATED_EMPULSE ATTENDANCE TABLE.xlsx";
   String ShiftDataPath= "D:\\Shift Allowance\\TEST DATA\\US9_TC4_REGRESSION TESTING_DATA CREATED_SHIFT DETAILS TABLE.xlsx";
    @BeforeTest
    public void CreatingData() throws Exception
    {
    	
    	DB.InsertingDataShiftDetails(ShiftDataPath);//INSERTING DATA INTO SHIFTDETAILS TABLE
    	DB.InsertingDataEmpulseAtt(EmpulseDataPath);//INSERING DATA INTO EMPULSEATTENDANCE TABLE
    }
    
  @AfterTest
    public void DeletingData() throws Exception
    {
    	Connection conn=DB.ConnectingToDB();
    	Statement smt = conn.createStatement();
         smt.executeUpdate("DELETE FROM   [ShiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseAttendance]  where EmpID='99960_FS' and Year =2018 and Month=9 ");
         smt.executeUpdate("DELETE FROM   [ShiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseShiftDetails]  where EmpID='99960_FS' and Year =2018 and Month=9 ");
         conn.close();
    
    }
    
    
    @BeforeClass
    public void LastThreeMonths() throws Exception
    {
  	  String[] months = new String[]{" ","January","February","March","April","May","June","July","August","September","October","November","December"};
	  Calendar now = Calendar.getInstance();
	  String[] NoOfDaysInMonth = new String[]{"","31","28","31","30","31","30","31","31","30","31","30","31"};

	  ExcelDataConfig excel1= new ExcelDataConfig(EmpulseDataPath);//Using the library designed to read the data i.e executing DATA DRIVEN approach
	  String index=excel1.getData(0, 0, 23) ;
	 int  monthno=Integer.parseInt(index);
	 totaldays=NoOfDaysInMonth[monthno];
	  MonthToBeChecked= months[monthno];
	  System.out.println(months[monthno]);
	  System.out.println(MonthToBeChecked);
	  int month= now.get(Calendar.MONTH) + 1; //Fetching the current month
		if(month>3)
		{    FirstMonth =  months[month-3];
			 SecondMonth =  months[month-2];
			ThirdMonth =  months[month-1];
		}
		
		else if (month==3)
		{
			FirstMonth =  months[12];
			 SecondMonth =  months[1];
			 ThirdMonth =  months[2];
		}
		
		else if (month==2)
		{
			 FirstMonth =  months[11];
			 SecondMonth =  months[12];
			 ThirdMonth =  months[1];
		}
		else if (month==1)
		{
			 FirstMonth =  months[10];
		    SecondMonth =  months[11];
			 ThirdMonth =  months[12];
		}
		if(MonthToBeChecked.equalsIgnoreCase(FirstMonth))
		{
			MonthToBeClicked=FirstMonth;
			xpathmonth="First";
		}
		else if(MonthToBeChecked.equalsIgnoreCase(SecondMonth))
		{
			MonthToBeClicked=SecondMonth;
			xpathmonth="Second";
		}
		else if(MonthToBeChecked.equalsIgnoreCase(ThirdMonth))
		{
			MonthToBeClicked=ThirdMonth;
			xpathmonth="Third";
		}
		else
		{
			System.out.println(MonthToBeChecked+"\tCalendar is not displayed");
			xpathmonth="lol, go find where is the mistake";
			System.out.println(xpathmonth);
		}
    }
    
	@BeforeMethod    //TestNG methods that are annotated with @BeforeMethod annotation will be run before executing each test method.
	public void setUp() throws Exception 
	{
		 driver = BrowserFactory.StartBrowser("Chrome", "https://shiftallowancesit.fs.capgemini.com");   //Using BrowserFactory tO LAUNCH THE BROWSER
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);   //Applying Implicit Wait		   
	}
	
	
	
	@AfterMethod   //TestNG methods that are annotated with @AfterMethod annotation will be run after executing each test method.
	public void tearDown(ITestResult result) {
		
		if(ITestResult.FAILURE==result.getStatus())
		{
			String ScrshotPath = Screenshot.CaptureScrShot(driver, LOCATION , result.getName());
			String image= logger.addScreenCapture(ScrshotPath);
			logger.log(LogStatus.FAIL, image);	 
		}
		
        report.endTest(logger); 
        report.flush();
       driver.quit();
	}
	
	
	
	@AfterSuite
	public void GenerateReport()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium Related\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
			driver.get("D:\\Shift Allowance\\AUTOMATION\\US7\\Reports\\Apply_Shift.html");
	}
	
	
	
	/*@Test(priority=3)
	public void Verify_Legend_Red_Present() throws Exception
	{
		logger= report.startTest("Legend Red Is Present or not?_TC6");
		logger.log(LogStatus.INFO,"Browser is up and Running");
		LoginPage login = PageFactory.initElements(driver, LoginPage.class);
		ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed  to read the data i.e executing DATA DRIVEN approach
	    String uid= excel.getData(0, 0,0);//storing the username
	    String pass=excel.getData(0, 0,1);//storing the password
	    login.LogIn(uid, pass);//LOGGING IN
		logger.log(LogStatus.INFO,"Successfully Logged IN");
		Home_Page home = PageFactory.initElements(driver, Home_Page.class);
		home.Shift();
		logger.log(LogStatus.INFO,"Home Page is up and running");
		Boolean isRedLegendPresent = driver.findElements(By.xpath("//*[@id='calendarlegend']/img[4]")).size()!=0;
		Assert.assertTrue(isRedLegendPresent);
		logger.log(LogStatus.PASS, "Legend Red Is Present");
	}
	
	
	
	
	
	@Test(priority=4)
	public void Verify_Legend_Orange_Present() throws Exception
	{
		logger= report.startTest("Legend Orange Is Present or not?_TC9");
		logger.log(LogStatus.INFO,"Browser is up and Running");
		LoginPage login = PageFactory.initElements(driver, LoginPage.class);
		ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed  to read the data i.e executing DATA DRIVEN approach
		String uid= excel.getData(0, 0,0);//storing the username
		String pass=excel.getData(0, 0,1);//storing the password
		login.LogIn(uid, pass);//Logging IN
		logger.log(LogStatus.INFO,"Successfully Logged IN");
		Home_Page home = PageFactory.initElements(driver, Home_Page.class);
		home.Shift();
		logger.log(LogStatus.INFO,"Home Page is up and running");
		Boolean isOrangeLegendPresent = driver.findElements(By.xpath("//*[@id='calendarlegend']/img[5]")).size()!=0;
		Assert.assertTrue(isOrangeLegendPresent);
		logger.log(LogStatus.PASS, "Legend Orange Is Present");
	}


	
	@Test(priority=5)
public void Verify_Autopopulate() throws Exception
{
	logger= report.startTest("Plus Sign Is Present or not?_TC1");
	logger.log(LogStatus.INFO,"Browser is up and Running");
	LoginPage login = PageFactory.initElements(driver, LoginPage.class);
	ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed by me to read the data i.e executing DATA DRIVEN approach
	String uid= excel.getData(0, 0,0);//storing the username
	String pass=excel.getData(0, 0,1);//storing the password
	login.LogIn(uid, pass);//Logging IN
	logger.log(LogStatus.INFO,"Successfully Logged IN");
	Home_Page home = PageFactory.initElements(driver, Home_Page.class);
	home.Shift();
	logger.log(LogStatus.INFO,"Home Page is up and running");
	Boolean isPlusSignPresent = driver.findElements(By.xpath("//*[@id='gvgriddetails']/tbody/tr[1]/td[4]/div/text/div[1]/div[2]")).size()!=0;//verifying if plus minus sign is present or not
	Assert.assertTrue(isPlusSignPresent);
	logger.log(LogStatus.PASS, "Plus Sign Is Present");
} 

	
	
	@Test(priority=2)
public void Verify_TC3_Message_Removed() throws Exception
{
	logger= report.startTest(" Message is Removed or not?_TC3");
	logger.log(LogStatus.INFO,"Browser is up and Running");
	LoginPage login = PageFactory.initElements(driver, LoginPage.class);
	ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed  to read the data i.e executing DATA DRIVEN approach
	String uid= excel.getData(0, 0,0);//storing the username
	String pass=excel.getData(0, 0,1);//storing the password
	login.LogIn(uid, pass);//LOGGING IN
	logger.log(LogStatus.INFO,"Successfully Logged IN");
	Home_Page home = PageFactory.initElements(driver, Home_Page.class);
	home.Shift();
	logger.log(LogStatus.INFO,"Home Page is up and running");
	Assert.assertFalse(driver.findElement(By.xpath("//*[text()='August Shift Roster will be visible from 25th August onwards']")).isDisplayed());
	logger.log(LogStatus.PASS, "Message Removed");
	
}


@Test(priority=1)
public void Verify_LastThreeMonth_Roaster_Available() throws Exception
{
	logger= report.startTest("LAST THREE MONTH ROASTER IS AVAILABLE OR NOT_TC5");
	logger.log(LogStatus.INFO,"Browser is up and Running");
	LoginPage login = PageFactory.initElements(driver, LoginPage.class);
	ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed by me to read the data i.e executing DATA DRIVEN approach
	String uid= excel.getData(0, 0,0);//storing the username
	String pass=excel.getData(0, 0,1);//storing the password
	login.LogIn(uid, pass);
	logger.log(LogStatus.INFO,"Successfully Logged IN");
	Home_Page home = PageFactory.initElements(driver, Home_Page.class);
	home.Shift();
	logger.log(LogStatus.INFO,"Home Page is up and running");
	Boolean isFirstMonthPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+FirstMonth+"']")).size()!=0;
	Assert.assertTrue(isFirstMonthPresent);
	logger.log(LogStatus.PASS, FirstMonth +"Calendar is Present");
	Boolean isSecondMonthPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+SecondMonth+"']")).size()!=0;
	Assert.assertTrue(isSecondMonthPresent);
	logger.log(LogStatus.PASS, SecondMonth +"Calendar is Present");
	Boolean isThirdMonthPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+ThirdMonth+"']")).size()!=0;
	Assert.assertTrue(isThirdMonthPresent);
	logger.log(LogStatus.PASS, ThirdMonth +"Calendar is Present");
	logger.log(LogStatus.INFO,"LAST THREE MONTH ROASTER IS AVAILABLE");
	
}*/


/*@Test(priority=19)
public void Verify_MessagaeDisplayed_If_RoasterNotAvailable() throws Exception
{
    Connection conn=DB.ConnectingToDB();
    ExcelDataConfig excel1= new ExcelDataConfig(ShiftDataPath);//Using the library designed to read the data i.e executing DATA DRIVEN approach
    PreparedStatement pstmt=conn.prepareStatement("DELETE FROM   [ShiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseShiftDetails]  where EmpID=?  AND YEAR=? AND MONTH=?");
    pstmt.setString( 1, excel1.getData(0, 0, 0)); 
    pstmt.setString( 2, excel1.getData(0,0 , 5));
    pstmt.setString( 3, excel1.getData(0, 0, 6));
    pstmt.executeUpdate();
    conn.close();    
        
	logger= report.startTest("Proper Message Displayed_If_Roasrer_Not_Available_TC2");
	logger.log(LogStatus.INFO,"Browser is up and Running");
	LoginPage login = PageFactory.initElements(driver, LoginPage.class);
	ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed by me to read the data i.e executing DATA DRIVEN approach
	String uid= excel.getData(0, 0,0);//storing the username
	String pass=excel.getData(0, 0,1);//storing the password
	login.LogIn(uid, pass);
	logger.log(LogStatus.INFO,"Successfully Logged IN");
	Home_Page home = PageFactory.initElements(driver, Home_Page.class);
	home.Shift();
	logger.log(LogStatus.INFO,"Home Page is up and running");
	Boolean isFirstMonthPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+FirstMonth+"']")).size()!=0;
		Assert.assertTrue(isFirstMonthPresent);
		logger.log(LogStatus.PASS, FirstMonth+"Calendar is Present");
		driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();
		Thread.sleep(5000);
	 Assert.assertTrue(driver.findElement(By.xpath("//*[text()='(Shift roster for September-2018 is not available from empulse application, please contact your Supervisor or you can apply for On-Call shift.)']")).isDisplayed());
	 logger.log(LogStatus.PASS, "Proper Message is being Displayed");

}*/

	
/*@Test(priority=10)
public void Verify_Highlighted_Red() throws Exception
{	
	
	Connection conn=DB.ConnectingToDB();
	Statement smt = conn.createStatement();
     smt.executeUpdate("UPDATE  [ShiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseAttendance] SET PunchInTime='',PunchOutTime='',ActHrsWorked='0:00:00',AttendanceClassification='AB' where EmpID='99960_FS' and Year =2018 and Month=9 AND Date=10");
	 ResultSet rs=smt.executeQuery("Select AttendanceClassification from  [ShiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseAttendance] where EmpID='99960_FS' and Year =2018 and Month=9 AND Date=10");
	 while(rs.next())
	 {
	 String AttendanceClassification= rs.getString("AttendanceClassification");
	 System.out.println("Database record is"+ AttendanceClassification);
	 
	 }
     conn.close();
	logger= report.startTest("HIGHLIGHTED in RED_TC7");
	logger.log(LogStatus.INFO,"Browser is up and Running");
	LoginPage login = PageFactory.initElements(driver, LoginPage.class);
	ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed by me to read the data i.e executing DATA DRIVEN approach
	String uid= excel.getData(0, 0,0);//storing the username
	String pass=excel.getData(0, 0,1);//storing the password
	login.LogIn(uid, pass);//LOGGING IN
	logger.log(LogStatus.INFO,"Successfully Logged IN");
	Home_Page home = PageFactory.initElements(driver, Home_Page.class);
	home.Shift();
	logger.log(LogStatus.INFO,"Home Page is up and running");
	Boolean isFirstMonthPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+FirstMonth+"']")).size()!=0;
	Assert.assertTrue(isFirstMonthPresent);
	logger.log(LogStatus.PASS, FirstMonth+"Calendar is Present");
	driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();
	String ExpectedColour = "#ff2a00";
	String color = driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr[3]/td[2]/div")).getCssValue("background-color");
	 System.out.println(color);
	 String ActualColour = Color.fromString(color).asHex();
	 System.out.println(ActualColour);
	 Assert.assertTrue(ActualColour.equalsIgnoreCase(ExpectedColour));
	 logger.log(LogStatus.PASS, "Absent Days are Highlighted in RED ");

}*/

/*@Test(priority=12)
public void Verify_Highlighted_Orange() throws Exception
{
     Connection conn=DB.ConnectingToDB();
	 Statement smt = conn.createStatement();
     smt.executeUpdate("UPDATE  [ShiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseAttendance] SET PunchOutTime='14:29:00',ActHrsWorked='08:29:00',AttendanceClassification='W(-)' where EmpID='99960_FS' and Year =2018 and Month=9 AND Date=11");
     ResultSet rs=smt.executeQuery("Select AttendanceClassification from  [ShiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseAttendance] where EmpID='99960_FS' and Year =2018 and Month=9 AND Date=11");
	 while(rs.next())
	 {
	 String AttendanceClassification= rs.getString("AttendanceClassification");
	 System.out.println("Database record is"+ AttendanceClassification);
	 
	 }
     conn.close();
	logger= report.startTest("Days with Insufficient work hours are highlighted in ORANGE_TC10");
	logger.log(LogStatus.INFO,"Browser is up and Running");
	LoginPage login = PageFactory.initElements(driver, LoginPage.class);
	ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed by me to read the data i.e executing DATA DRIVEN approach
	String uid= excel.getData(0, 0,0);//storing the username
	String pass=excel.getData(0, 0,1);//storing the password
	login.LogIn(uid, pass);
	logger.log(LogStatus.INFO,"Successfully Logged IN");
	Home_Page home = PageFactory.initElements(driver, Home_Page.class);
	home.Shift();
	logger.log(LogStatus.INFO,"Home Page is up and running");
	Boolean isFirstMonthPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+FirstMonth+"']")).size()!=0;
	Assert.assertTrue(isFirstMonthPresent);
	logger.log(LogStatus.PASS, FirstMonth+"Calendar is Present");
	 driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();
	 Thread.sleep(2000);
	 String ExpectedColour = "#FF7F50";
	String color = driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr[3]/td[3]/div")).getCssValue("background-color");
	 System.out.println(color);
	 String ActualColour = Color.fromString(color).asHex();
	 System.out.println(ActualColour);
	 Assert.assertTrue(ActualColour.equalsIgnoreCase(ExpectedColour));
	 logger.log(LogStatus.PASS, "Days with Insufficient work hours are highlighted in ORANGE");


}*/

/*@Test(priority=11)
public void Verify_AbsentDay_DontHave_PlusSign() throws Exception
{
	logger= report.startTest("ABSENT days do not have PLUS sign_TC8");
	logger.log(LogStatus.INFO,"Browser is up and Running");
	LoginPage login = PageFactory.initElements(driver, LoginPage.class);
	ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed  to read the data i.e executing DATA DRIVEN approach
	String uid= excel.getData(0, 0,0);//storing the username
	String pass=excel.getData(0, 0,1);//storing the password
	login.LogIn(uid, pass);
    logger.log(LogStatus.INFO,"Successfully Logged IN");
	Home_Page home = PageFactory.initElements(driver, Home_Page.class);
	home.Shift();
	logger.log(LogStatus.INFO,"Home Page is up and running");
	Boolean isFirstMonthPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+FirstMonth+"']")).size()!=0;
	Assert.assertTrue(isFirstMonthPresent);
	logger.log(LogStatus.PASS, FirstMonth+"Calendar is Present");
	 driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();
	
	Boolean isPlusSignPresent = driver.findElements(By.xpath("//*[@id='gvgriddetails']/tbody/tr[3]/td[2]/div/text/div[1]/div[2]")).size()!=0;//verifying if plus minus sign is absent
	Assert.assertFalse(isPlusSignPresent);
	
	logger.log(LogStatus.PASS, "ABSENT days do not have PLUS sign");
}*/

/*@Test(priority=13)
public void Verify_OrangeHighlighted_DontHave_PlusSign() throws Exception
{
	logger= report.startTest("Days highlighted in ORANGE do not have PLUS sign_TC11");
	logger.log(LogStatus.INFO,"Browser is up and Running");
	LoginPage login = PageFactory.initElements(driver, LoginPage.class);
	ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed by me to read the data i.e executing DATA DRIVEN approach
	String uid= excel.getData(0, 0,0);//storing the username
	String pass=excel.getData(0, 0,1);//storing the password
	login.LogIn(uid, pass);
	logger.log(LogStatus.INFO,"Successfully Logged IN");
	Home_Page home = PageFactory.initElements(driver, Home_Page.class);
	home.Shift();
	logger.log(LogStatus.INFO,"Home Page is up and running");
	Boolean isFirstMonthPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+FirstMonth+"']")).size()!=0;
	Assert.assertTrue(isFirstMonthPresent);
    logger.log(LogStatus.PASS, FirstMonth+"Calendar is Present");
    driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();
	
	Boolean isPlusSignPresent = driver.findElements(By.xpath("//*[@id='gvgriddetails']/tbody/tr[3]/td[3]/div/text/div[1]/div[2]")).size()!=0;//verifying if plus minus sign is absent
	Assert.assertFalse(isPlusSignPresent);
	logger.log(LogStatus.PASS, "Days with insufficient working hours do not have PLUS sign");
	
}*/

/*@Test(priority=6)
public void Verify_ShiftType_NotEditable() throws Exception
{
	logger= report.startTest("Shift Type Field Is Selected_TC12");
	logger.log(LogStatus.INFO,"Browser is up and Running");
	LoginPage login = PageFactory.initElements(driver, LoginPage.class);
	ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed  to read the data i.e executing DATA DRIVEN approach
	String uid= excel.getData(0, 0,0);//storing the username
	String pass=excel.getData(0, 0,1);//storing the password
	login.LogIn(uid, pass);//LOGGING IN
	logger.log(LogStatus.INFO,"Successfully Logged IN");
	Home_Page home = PageFactory.initElements(driver, Home_Page.class);
	home.Shift();
	logger.log(LogStatus.INFO,"Home Page is up and running");
	Boolean isSecondMonthPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+SecondMonth+"']")).size()!=0;
	Assert.assertTrue(isSecondMonthPresent);
	logger.log(LogStatus.PASS, SecondMonth +"Calendar is Present");
    driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();
    WebDriverWait wait=new WebDriverWait(driver, 20);
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='gvgriddetails']/tbody/tr[2]/td[3]/div/div[1]/div[2]/img[@id='imgMon']")));
	Thread.sleep(4000);
	driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr[2]/td[3]/div/div[1]/div[2]/img[@id='imgMon']")).click();
	WebDriverWait wait1=new WebDriverWait(driver, 20);
	wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='myform']/table/tbody/tr[2]/td[2]")));
	Boolean Noteditable= driver.findElement(By.xpath("//*[@id='ddlselectShiftList1']")).getAttribute("disabled");
    Assert.assertTrue(Noteditable);
    logger.log(LogStatus.PASS, "Shift Type field is Not Editable");
}



@Test(priority=7)
public void Verify_Project_TaskDetails_Editable() throws Exception
{
	logger= report.startTest("Field PROJECT and TASK DETAILS is EDITABLE_TC13");
	logger.log(LogStatus.INFO,"Browser is up and Running");
	LoginPage login = PageFactory.initElements(driver, LoginPage.class);
	ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed  to read the data i.e executing DATA DRIVEN approach
	String uid= excel.getData(0, 0,0);//storing the username
	String pass=excel.getData(0, 0,1);//storing the password
	login.LogIn(uid, pass);//Logging IN
	logger.log(LogStatus.INFO,"Successfully Logged IN");
	Home_Page home = PageFactory.initElements(driver, Home_Page.class);
	home.Shift();
	logger.log(LogStatus.INFO,"Home Page is up and running");
	Boolean isSecondMonthPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+SecondMonth+"']")).size()!=0;
	Assert.assertTrue(isSecondMonthPresent);
	logger.log(LogStatus.PASS, SecondMonth+"Calendar is Present");
	driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();
	 WebDriverWait wait=new WebDriverWait(driver, 20);
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='gvgriddetails']/tbody/tr[2]/td[3]/div/div[1]/div[2]/img[@id='imgMon']")));
	Thread.sleep(4000);
	driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr[2]/td[3]/div/div[1]/div[2]/img[@id='imgMon']")).click();
	WebDriverWait wait1=new WebDriverWait(driver, 20);
	wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='myform']/table/tbody/tr[2]/td[2]")));
	Boolean ProjEditable= driver.findElement(By.xpath("//*[@id='ddlselectProjectList1']")).getAttribute("disabled");
    Assert.assertTrue(Noteditable);
    logger.log(LogStatus.PASS, "Shift Type field is Not Editable");
    Assert.assertFalse(ProjEditable);
    logger.log(LogStatus.PASS, "Field PROJECT is EDITABLE");
    Boolean TaskDetails_Editable = driver.findElement(By.xpath("//*[@id='ddlselectTaskList1']")).getAttribute("disabled");
    Assert.assertFalse(TaskDetails_Editable);
    logger.log(LogStatus.PASS, "Field TASK is EDITABLE");
	
}

@Test(priority=8)
public void Verify_ShiftType_NotPresent_BulUpload() throws Exception
{
	logger= report.startTest("Field SHIFT TYPE is not present in case of BULK UPLOAD_TC14");
	logger.log(LogStatus.INFO,"Browser is up and Running");
	LoginPage login = PageFactory.initElements(driver, LoginPage.class);
	ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed to read the data i.e executing DATA DRIVEN approach
	String uid= excel.getData(0, 0,0);//storing the username
	String pass=excel.getData(0, 0,1);//storing the password
	login.LogIn(uid, pass);//LOGGING IN
	logger.log(LogStatus.INFO,"Successfully Logged IN");
	Home_Page home = PageFactory.initElements(driver, Home_Page.class);
	home.Shift();
	logger.log(LogStatus.INFO,"Home Page is up and running");
	Boolean ShiftType = driver.findElements(By.xpath("//*[text()='Shift Type']")).size()==0;
	Assert.assertTrue(ShiftType);
	logger.log(LogStatus.PASS, "Field SHIFT TYPE is not present in case of BULK UPLOAD");
}




	@Test(priority=9)
	public void Verify_Project_TaskDetails_BulkUpload_Editable() throws Exception
	{
		logger= report.startTest("Field PROJECT and TASK DETAILS  is  present in case of BULK UPLOAD_TC15");
		logger.log(LogStatus.INFO,"Browser is up and Running");
		LoginPage login = PageFactory.initElements(driver, LoginPage.class);
		ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed to read the data i.e executing DATA DRIVEN approach
		String uid= excel.getData(0, 0,0);//storing the username
		String pass=excel.getData(0, 0,1);//storing the password
		login.LogIn(uid, pass);//LOGGING IN
		logger.log(LogStatus.INFO,"Successfully Logged IN");
		Home_Page home = PageFactory.initElements(driver, Home_Page.class);
		home.Shift();
		logger.log(LogStatus.INFO,"Home Page is up and running");
		Boolean isSecondMonthPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+SecondMonth+"']")).size()!=0;
		Assert.assertTrue(isSecondMonthPresent);
		logger.log(LogStatus.PASS, SecondMonth +"Calendar is Present");
		driver.findElement(By.xpath("//*[@id='SecondMonth']/div/table")).click();
		Boolean ProjEditable = driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[6]")).isEnabled();
	    Assert.assertTrue(ProjEditable);
	    logger.log(LogStatus.PASS, "Field PROJECT is EDITABLE");
	    Boolean TaskDetails_Editable = driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[8]")).isEnabled();
	    Assert.assertTrue(TaskDetails_Editable);
	    logger.log(LogStatus.PASS, "Field TASK DETAILS  is EDITABLE");
	}*/
	
	
	
	
	
	/*@Test(priority=14)
	public void Verify_Message_SwipeDetailsNotAvailableForEntireMonth_Displayed() throws Exception
	{
		Connection conn=DB.ConnectingToDB();
	    ExcelDataConfig excel1= new ExcelDataConfig(EmpulseDataPath);//Using the library designed to read the data i.e executing DATA DRIVEN approach
	    PreparedStatement pstmt=conn.prepareStatement("DELETE FROM   [ShiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseAttendance]  where EmpID=?  AND YEAR=? AND MONTH=?");
	    pstmt.setString( 1, excel1.getData(0, 0, 0)); 
	    pstmt.setString( 2, excel1.getData(0,0 , 22));
	    pstmt.setString( 3, excel1.getData(0, 0, 23));
	    pstmt.executeUpdate();
	    conn.close();  
		logger= report.startTest("Proper Message Corresponding to SwipeDetailsNotAvailableForEntireMonth is Displayed_TC16");
		logger.log(LogStatus.INFO,"Browser is up and Running");
		LoginPage login = PageFactory.initElements(driver, LoginPage.class);
		ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed by me to read the data i.e executing DATA DRIVEN approach
		String uid= excel.getData(0, 0,0);//storing the username
		String pass=excel.getData(0, 0,1);//storing the password
		login.LogIn(uid, pass);
		logger.log(LogStatus.INFO,"Successfully Logged IN");
		Home_Page home = PageFactory.initElements(driver, Home_Page.class);
		home.Shift();
		logger.log(LogStatus.INFO,"Home Page is up and running");
		Boolean isFirstMonthPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+FirstMonth+"']")).size()!=0;
		Assert.assertTrue(isFirstMonthPresent);
		logger.log(LogStatus.PASS, FirstMonth+"Calendar is Present");
		driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();
		Boolean SwipeDetails = driver.findElement(By.xpath("//*[text()='Swipe details not available from Empulse for certain days. In case of employees working from home/Client Location, please have your regularized attendance approved by Supervisor in Empulse application.']")).isDisplayed();
		Assert.assertTrue(SwipeDetails);
		logger.log(LogStatus.PASS, "Proper Message Corresponding to SwipeDetailsNotAvailableForEntireMonth is Displayed");
	}
	
	/*@Test(priority=17)
	public void Verify_PlusSign_Present_LWD() throws Exception
	{
		logger= report.startTest("Is Employee Able to apply shift request until LWD_TC17");
		logger.log(LogStatus.INFO,"Browser is up and Running");
		LoginPage login = PageFactory.initElements(driver, LoginPage.class);
		ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed by me to read the data i.e executing DATA DRIVEN approach
		String uid= excel.getData(0, 0,0);//storing the username
		String pass=excel.getData(0, 0,1);//storing the password
		login.LogIn(uid, pass);
				logger.log(LogStatus.INFO,"Successfully Logged IN");
		Home_Page home= PageFactory.initElements(driver, Home_Page.class);
		home.Shift();
		logger.log(LogStatus.INFO,"Home Page is up and running");
		Boolean isAugPresent = driver.findElements(By.xpath("//*[@id='FirstMonth']/div/table")).size()!=0;

		Assert.assertTrue(isAugPresent);
		logger.log(LogStatus.PASS, "August Month Calendar is present");
		driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();
		Boolean isPlusSignPresent = driver.findElements(By.xpath("//*[@id='gvgriddetails']/tbody/tr[1]/td[4]/div/text/div[1]/div[2]")).size()!=0;//verifying if plus minus sign is present on LWD
		Assert.assertTrue(isPlusSignPresent);
		logger.log(LogStatus.PASS, "Employee is Able to apply shift request until LWD");

	}*/
	
	/*@Test()
	public void Verify_ShiftType_LWD_Editable() throws Exception
	{
		logger= report.startTest("Is The field 'SHIFT TYPE' Editable until LWD_TC18");
		logger.log(LogStatus.INFO,"Browser is up and Running");

		LoginPage login = PageFactory.initElements(driver, LoginPage.class);
		ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed by me to read the data i.e executing DATA DRIVEN approach
		String uid= excel.getData(0, 0,0);//storing the username
		String pass=excel.getData(0, 0,1);//storing the password
		login.LogIn(uid, pass);
				logger.log(LogStatus.INFO,"Successfully Logged IN");

		Home_Page home = PageFactory.initElements(driver, Home_Page.class);
		home.Shift();
		logger.log(LogStatus.INFO,"Home Page is up and running");

		Boolean isAugPresent = driver.findElements(By.xpath("//*[@id='FirstMonth']/div/table")).size()!=0;
		Assert.assertTrue(isAugPresent);
		logger.log(LogStatus.PASS, "August Month Calendar is present");

		driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();
		Boolean isPlusSignPresent = driver.findElements(By.xpath("//*[@id='gvgriddetails']/tbody/tr[1]/td[4]/div/text/div[1]/div[2]")).size()!=0;//verifying if plus minus sign is present on LWD

		Assert.assertTrue(isPlusSignPresent);
		logger.log(LogStatus.PASS, "Plus sign is present on LWD");
		
		WebElement PlusSign= driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr[1]/td[4]/div/text/div[1]/div[2]"));//+sign of LWD, make sure to edit the xpath when doing execution i.e change the tr[] and td[]
		 
		Actions actions = new Actions(driver);
		actions.moveToElement(PlusSign).click().perform();
		
		 Boolean Editable = driver.findElement(By.xpath("//*[@id='myform']/table/tbody/tr[2]/td[2]")).isEnabled();//Shift type editable or nat

		    Assert.assertFalse(Editable);
			logger.log(LogStatus.PASS, "The field 'SHIFT TYPE' is Editable until LWD");

	}*/
	/*@Test(priority=18)
	public void Verify_Message_NotDisplayed_ShiftPresent_ForOneDay() throws Exception
	{
		Connection conn=DB.ConnectingToDB();
    	Statement smt = conn.createStatement();
    ExcelDataConfig excel1= new ExcelDataConfig(EmpulseDataPath);//Using the library designed by me to read the data i.e executing DATA DRIVEN approach

        PreparedStatement pstmt=conn.prepareStatement("DELETE FROM   [ShiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseShiftDetails]  where EmpID=? and ShiftDate !=?");
         pstmt.setString( 1, excel1.getData(0, 1, 0)); 
	 pstmt.setString( 2, excel1.getData(0, 1, 14)); 
	 pstmt.executeUpdate();
         conn.close();
		logger= report.startTest("The Message Is Not Displayed if 'Shift Type' is defined even for ONE DAY _TC19");
		logger.log(LogStatus.INFO,"Browser is up and Running");
		LoginPage login = PageFactory.initElements(driver, LoginPage.class);
		ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed by me to read the data i.e executing DATA DRIVEN approach
		String uid= excel.getData(0, 0,0);//storing the username
		String pass=excel.getData(0, 0,1);//storing the password
		login.LogIn(uid, pass);
		Home_Page home = PageFactory.initElements(driver, Home_Page.class);
		home.Shift();
		logger.log(LogStatus.INFO,"Home Page is up and running");
		Boolean isFirstMonthPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+FirstMonth+"']")).size()!=0;
		Assert.assertTrue(isFirstMonthPresent);
		logger.log(LogStatus.PASS, FirstMonth+"Calendar is Present");
		driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();
		Assert.assertFalse(driver.findElements(By.xpath("//*[text()='(Shift roaster for September-2018 is not available from empulse application, please contact your Supervisor or you can apply for On Call.)']")).size()!=0);
		logger.log(LogStatus.PASS, "Message Not Displayed");

		
	}

@Test(priority=15)
public void Verify_MessageNotDisplayed_ShiftDefined_FewDays() throws Exception
{
	Connection conn=DB.ConnectingToDB();
	Statement smt = conn.createStatement();
	 DB.InsertingDataEmpulseAtt(EmpulseDataPath);
    smt.executeUpdate("DELETE FROM   [ShiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseShiftDetails]  where EmpID='99960_FS' and Year =2018 and Month=9 and DATE not in(4,5,6) ");
     conn.close();
	logger= report.startTest("The Message Is Not Displayed if 'Shift Type' is defined for PARTICULAR DAYS _TC20");
	logger.log(LogStatus.INFO,"Browser is up and Running");
	LoginPage login = PageFactory.initElements(driver, LoginPage.class);
	ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed by me to read the data i.e executing DATA DRIVEN approach
	String uid= excel.getData(0, 0,0);//storing the username
	String pass=excel.getData(0, 0,1);//storing the password
	login.LogIn(uid, pass);
	Home_Page home = PageFactory.initElements(driver, Home_Page.class);
	home.Shift();
	logger.log(LogStatus.INFO,"Home Page is up and running");
	Boolean isFirstMonthPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+FirstMonth+"']")).size()!=0;
	Assert.assertTrue(isFirstMonthPresent);
	logger.log(LogStatus.PASS, FirstMonth+"Calendar is Present");
	driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();
	Assert.assertFalse(driver.findElements(By.xpath("//*[text()='(Shift roaster for September-2018 is not available from empulse application, please contact your Supervisor or you can apply for On Call shift.)']")).size()!=0);
	logger.log(LogStatus.PASS, "Message Not Displayed");

	
}
@Test(priority=16)
public void Verify_PlusSign_Present_On_AllDays_ShiftDefined_OnlyFewDays() throws Exception
{
	logger= report.startTest("Plus Sign Is Present For All Days_Though Shift Defined for few days _TC22");
	logger.log(LogStatus.INFO,"Browser is up and Running");
	LoginPage login = PageFactory.initElements(driver, LoginPage.class);
	ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed by me to read the data i.e executing DATA DRIVEN approach
	String uid= excel.getData(0, 0,0);//storing the username
	String pass=excel.getData(0, 0,1);//storing the password
	login.LogIn(uid, pass);
	Home_Page home = PageFactory.initElements(driver, Home_Page.class);
	home.Shift();
	logger.log(LogStatus.INFO,"Home Page is up and running");
	Boolean isFirstMonthPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+FirstMonth+"']")).size()!=0;
	Assert.assertTrue(isFirstMonthPresent);
	logger.log(LogStatus.PASS, FirstMonth+"Calendar is Present");
	driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();
	WebDriverWait wait=new WebDriverWait(driver, 30);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='GetData']")));
	int count=0;
	Boolean isPlusSignPresent=null;
	Boolean isPlusSignOnAllDays;
	
		for(int i=1;i<=6;i++)
			{
			
		for(int j=1;j<=3;j++)
		{
			
	 isPlusSignPresent = driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+i+"]/td["+j+"]/div/div[1]/div[2]/img[@id='imgMon']")).isDisplayed();//verifying if plus minus sign is present or not
	
	if(isPlusSignPresent==true)
	{
		count+=1;
		System.out.println(i+","+j);
		
		
	}
	isPlusSignPresent=null;
		}
	for(int k=4;k<=7;k++)
	{
		
		isPlusSignPresent = driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+i+"]/td["+k+"]/div/text/div[1]/div[2]/img[@id='imgMon']")).isDisplayed();//verifying if plus minus sign is present or not
		
		if(isPlusSignPresent)
		{
			count+=1;
			System.out.println(i+","+k);
			
			
		}
		isPlusSignPresent=null;
}
		
}	

if(count==30)
{
	 isPlusSignOnAllDays= true;
}
else
{
	 isPlusSignOnAllDays= false;
}
System.out.println("count is\t:"+count);
Assert.assertTrue(isPlusSignOnAllDays);
logger.log(LogStatus.PASS, "Plus Sign Is Present On All Working Days");

}
@Test(priority=16)
public void Verify_ShiftType_Correctlyinput() throws Exception
{
    
	logger= report.startTest("Shift Type Field Is Correctly Input_TC25");
	logger.log(LogStatus.INFO,"Browser is up and Running");
	LoginPage login = PageFactory.initElements(driver, LoginPage.class);
	ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed  to read the data i.e executing DATA DRIVEN approach
	String uid= excel.getData(0, 0,0);//storing the username
	String pass=excel.getData(0, 0,1);//storing the password
	login.LogIn(uid, pass);//LOGGING IN
	logger.log(LogStatus.INFO,"Successfully Logged IN");
	Home_Page home = PageFactory.initElements(driver, Home_Page.class);
	home.Shift();
	logger.log(LogStatus.INFO,"Home Page is up and running");
	Boolean isFirstMonthPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+FirstMonth+"']")).size()!=0;
	Assert.assertTrue(isFirstMonthPresent);
	logger.log(LogStatus.PASS, FirstMonth+"Calendar is Present");
	driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();
	WebDriverWait wait=new WebDriverWait(driver, 30);
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='gvgriddetails']/tbody/tr[2]/td[3]/div/div[1]/div[2]/img[@id='imgMon']")));
	Thread.sleep(4000);
	driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr[2]/td[3]/div/div[1]/div[2]/img[@id='imgMon']")).click();
	WebDriverWait wait1=new WebDriverWait(driver, 30);
	wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='myform']/table/tbody/tr[2]/td[2]")));
	String ShiftTypeDisabled= driver.findElement(By.xpath("//*[@id='ddlselectShiftList1']")).getAttribute("disabled");
	System.out.println("ShifType Disabled?:\t"+ ShiftTypeDisabled);
	Select select = new Select(driver.findElement(By.xpath("//*[@id='ddlselectShiftList1']")));
	WebElement option = select.getFirstSelectedOption();
	String ShiftType = option.getText();
	System.out.println("selected Value\t " + ShiftType);
    DB.ConnectingToDB();
      
	String ShiftCode=null;
	Connection conn=DB.ConnectingToDB();

	 PreparedStatement pstmt = conn.prepareStatement( "select ShiftCode from [ShiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseAttendance] where EmpID=? and InOutDate=?" );
	 ExcelDataConfig excel1= new ExcelDataConfig(EmpulseDataPath);
	 pstmt.setString( 1, excel1.getData(0, 1, 0)); 
	 pstmt.setString( 2, excel1.getData(0, 1, 14)); 
	 ResultSet rs= pstmt.executeQuery( );
    while(rs.next())
	{
	ShiftCode= rs.getString("ShiftCode");
	System.out.println("Database record is\t"+ ShiftCode);
	}
    conn.close();
    Assert.assertTrue(ShiftType.contains(ShiftCode));
    logger.log(LogStatus.PASS, "Shift Type Field Is Correctly Input");
}


@Test(priority=17)
public void Verify_ShiftType_Correctlyinput_For_ONCALL_ShiftDefined_FewDays() throws Exception
{

	logger= report.startTest("Shift Type Field Is Correctly Input_For_ONCALL_TC24");
	logger.log(LogStatus.INFO,"Browser is up and Running");
	LoginPage login = PageFactory.initElements(driver, LoginPage.class);
	ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed  to read the data i.e executing DATA DRIVEN approach
	String uid= excel.getData(0, 0,0);//storing the username
	String pass=excel.getData(0, 0,1);//storing the password
	login.LogIn(uid, pass);//LOGGING IN
	logger.log(LogStatus.INFO,"Successfully Logged IN");
	Home_Page home = PageFactory.initElements(driver, Home_Page.class);
	home.Shift();
	logger.log(LogStatus.INFO,"Home Page is up and running");
	Boolean isFirstMonthPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+FirstMonth+"']")).size()!=0;
	Assert.assertTrue(isFirstMonthPresent);
	logger.log(LogStatus.PASS, FirstMonth+"Calendar is Present");
	driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();
	WebDriverWait wait=new WebDriverWait(driver, 30);
	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='gvgriddetails']/tbody/tr[2]/td[6]/div/text/div[1]/div[2]/img[@id='imgMon']")));
	Thread.sleep(6000);
	driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr[2]/td[6]/div/text/div[1]/div[2]/img[@id='imgMon']")).click();
	WebDriverWait wait1=new WebDriverWait(driver, 30);
	wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='myform']/table/tbody/tr[2]/td[2]")));
    String ShiftTypeDisabled= driver.findElement(By.xpath("//*[@id='ddlselectShiftList1']")).getAttribute("disabled");
	System.out.println("ShifType Disabled?:\t"+ ShiftTypeDisabled);
	Select select = new Select(driver.findElement(By.xpath("//*[@id='ddlselectShiftList1']")));
	WebElement option = select.getFirstSelectedOption();
	String ShiftType = option.getText();
	System.out.println("selected Value\t " + ShiftType);	
    Assert.assertTrue(ShiftType.equalsIgnoreCase("On Call"));
    logger.log(LogStatus.PASS, "Shift Type Field Is Correctly Input");
}*/

/*@Test(priority=20)
public void Verify_PlusSign_Present_On_AllDays_Shift_NotDefined() throws Exception
{
	
	logger= report.startTest("Plus Sign Is Present For All Days_Though Shift Defined for few days _TC21");
	logger.log(LogStatus.INFO,"Browser is up and Running");
	LoginPage login = PageFactory.initElements(driver, LoginPage.class);
	ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed by me to read the data i.e executing DATA DRIVEN approach
	String uid= excel.getData(0, 0,0);//storing the username
	String pass=excel.getData(0, 0,1);//storing the password
	login.LogIn(uid, pass);
	Home_Page home = PageFactory.initElements(driver, Home_Page.class);
	home.Shift();
	logger.log(LogStatus.INFO,"Home Page is up and running");
	Boolean isFirstMonthPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+FirstMonth+"']")).size()!=0;
	Assert.assertTrue(isFirstMonthPresent);
	logger.log(LogStatus.PASS, FirstMonth+"Calendar is Present");
	driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();
	WebDriverWait wait=new WebDriverWait(driver, 30);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='GetData']")));
	int count=0;
	Boolean isPlusSignPresent=null;
	Boolean isPlusSignOnAllDays;
	
		for(int i=1;i<=6;i++)
			{
			
		for(int j=1;j<=3;j++)
		{
			
	 isPlusSignPresent = driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+i+"]/td["+j+"]/div/div[1]/div[2]/img[@id='imgMon']")).isDisplayed();//verifying if plus minus sign is present or not
	
	if(isPlusSignPresent==true)
	{
		count+=1;
		System.out.println(i+","+j);
		
		
	}
	isPlusSignPresent=null;
		}
	for(int k=4;k<=7;k++)
	{
		
		isPlusSignPresent = driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+i+"]/td["+k+"]/div/text/div[1]/div[2]/img[@id='imgMon']")).isDisplayed();//verifying if plus minus sign is present or not
		
		if(isPlusSignPresent)
		{
			count+=1;
			System.out.println(i+","+k);
			
			
		}
		isPlusSignPresent=null;
}
		
}	

if(count==30)
{
	 isPlusSignOnAllDays= true;
}
else
{
	 isPlusSignOnAllDays= false;
}
System.out.println("count is\t:"+count);
Assert.assertTrue(isPlusSignOnAllDays);
logger.log(LogStatus.PASS, "Plus Sign Is Present On All Working Days");

}*/

@Test(priority=21)
public void Verify_ShiftType_Correctlyinput_ONCALL_Shift_NotDefined() throws Exception
{

	Connection conn=DB.ConnectingToDB();
    ExcelDataConfig excel1= new ExcelDataConfig(ShiftDataPath);//Using the library designed to read the data i.e executing DATA DRIVEN approach
    PreparedStatement pstmt=conn.prepareStatement("DELETE FROM   [ShiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseShiftDetails]  where EmpID=?  AND YEAR=? AND MONTH=?");
    pstmt.setString( 1, excel1.getData(0, 0, 0)); 
    pstmt.setString( 2, excel1.getData(0,0 , 5));
    pstmt.setString( 3, excel1.getData(0, 0, 6));
    pstmt.executeUpdate();
    conn.close();
	logger= report.startTest("Shift Type Field Is ONCALL For All The Days Of The Month_TC23");
	logger.log(LogStatus.INFO,"Browser is up and Running");
	LoginPage login = PageFactory.initElements(driver, LoginPage.class);
	ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed  to read the data i.e executing DATA DRIVEN approach
	String uid= (String) excel.getData(0, 0,0);//storing the username
	String pass=(String) excel.getData(0, 0,1);//storing the password
	login.LogIn(uid, pass);//LOGGING IN
	logger.log(LogStatus.INFO,"Successfully Logged IN");
	Home_Page home = PageFactory.initElements(driver, Home_Page.class);
	home.Shift();
	logger.log(LogStatus.INFO,"Home Page is up and running");
	Boolean isMonthToBeClickedPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+MonthToBeClicked+"']")).size()!=0;
	Assert.assertTrue(isMonthToBeClickedPresent);
	logger.log(LogStatus.PASS, MonthToBeClicked+"Calendar is Present");
	if(xpathmonth.equalsIgnoreCase("First"))
	{
	driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();
	}
	else if(xpathmonth.equalsIgnoreCase("Second"))
	{
	driver.findElement(By.xpath("//*[@id='SecondMonth']/div/table")).click();
	} 
	else if(xpathmonth.equalsIgnoreCase("Third"))
	{
	driver.findElement(By.xpath("//*[@id='ThirdMonth']/div/table")).click();
	} 
	else{
		System.out.println("Dude You Messed Up");
	}
	WebDriverWait wait=new WebDriverWait(driver, 40);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='GetData']")));
	Thread.sleep(6000);
	WebDriverWait wait1=new WebDriverWait(driver, 100);
   
	String ShiftType;
	int count=0;
	Boolean isPlusSignPresent=null;
	Boolean ShiftTypeIsOnCall=null;
	for(int i=1;i<=3;i++)
			{
			
		for(int j=1;j<=3;j++)
		{
			
	 isPlusSignPresent = driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+i+"]/td["+j+"]/div/div[1]/div[2]/img[@id='imgMon']")).isDisplayed();//verifying if plus minus sign is present or not
	
		if(isPlusSignPresent)
		{
				try {
					wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+i+"]/td["+j+"]/div/div[1]/div[2]/img[@id='imgMon']"))));
					Thread.sleep(4000);
					driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+i+"]/td["+j+"]/div/div[1]/div[2]/img[@id='imgMon']")).click();
					wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='myform']/table/tbody/tr[2]/td[2]")));
					Thread.sleep(4000);
					Select select = new Select(driver.findElement(By.xpath("//*[@id='ddlselectShiftList1']")));
					WebElement option = select.getFirstSelectedOption();
					ShiftType = option.getText();
					Thread.sleep(2000);

					if(ShiftType.contains("On Call"))
					{
						count+=1;
						System.out.println("Shift type is\t"+ShiftType+"\tfor\t"+i+","+j);
					}
					driver.findElement(By.xpath("//*[@id='myModal']/div/div/div[1]/button")).click();
				} catch (Exception e) {
					System.out.println(e.getMessage());
					continue;
				}	   
		}
		else
		{
			System.out.println("Plus Sign not present for\t"+i+","+j);
		continue;	
		}
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='GetData']")));

		}
		
	for(int k=4;k<=7;k++)
	{
		isPlusSignPresent = driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+i+"]/td["+k+"]/div/text/div[1]/div[2]/img[@id='imgMon']")).isDisplayed();//verifying if plus minus sign is present or not

		if(isPlusSignPresent)
		{
			try {
				wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+i+"]/td["+k+"]/div/text/div[1]/div[2]/img[@id='imgMon']"))));
				Thread.sleep(4000);
				driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+i+"]/td["+k+"]/div/text/div[1]/div[2]/img[@id='imgMon']")).click();
				wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='myform']/table/tbody/tr[2]/td[2]")));
				Select select = new Select(driver.findElement(By.xpath("//*[@id='ddlselectShiftList1']")));
				WebElement option = select.getFirstSelectedOption();
				 ShiftType = option.getText();
				
if(ShiftType.contains("On Call"))
{
				count+=1;
				System.out.println("Shift type is\t"+ShiftType+"\tfor\t"+i+","+k);	
}

driver.findElement(By.xpath("//*[@id='myModal']/div/div/div[1]/button")).click();
			} 
			catch (Exception e) 
			{
				System.out.println(e.getMessage());
			}
		}
			else
			{
				System.out.println("Plus Sign not present for\t"+i+","+k);
			continue;	
			}
				
			
		}	
}	
	
	WebElement element =  driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr[4]"));
	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	Thread.sleep(500);
	for(int i=4;i<=6;i++)
	{
	System.out.println("Entered the m loop\t"+i);
for(int j=1;j<=3;j++)
{
	System.out.println("Entered the n loop\t"+j);
isPlusSignPresent = driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+i+"]/td["+j+"]/div/div[1]/div[2]/img[@id='imgMon']")).isDisplayed();//verifying if plus minus sign is present or not

if(isPlusSignPresent)
{
	System.out.println("Entered the if statement of n loop ");
		try {
			System.out.println("entered the try block of n loop");
			wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+i+"]/td["+j+"]/div/div[1]/div[2]/img[@id='imgMon']"))));
			Actions actions = new Actions(driver);
		    actions.moveToElement(driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+i+"]/td["+j+"]/div/div[1]/div[2]/img[@id='imgMon']"))).click();
		    actions.build().perform();
		    wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='myform']/table/tbody/tr[2]/td[2]")));
			Thread.sleep(4000);
			 ShiftType= driver.findElement(By.xpath("//*[@id='ddlselectShiftList1']")).getText();
			 Thread.sleep(2000);

			if(ShiftType.contains("On Call"))
			{
				count+=1;
				System.out.println("Shift type is\t"+ShiftType+"\tfor\t"+i+","+j);
			}
			driver.findElement(By.xpath("//*[@id='myModal']/div/div/div[1]/button")).click();
		} catch (Exception e) {
			System.out.println("enetered the catch block of n loop");
			e.getMessage();
		}	   
}
else
{
	System.out.println("Plus Sign not present for\t"+i+","+k);
continue;	

}



}
wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='GetData']")));

for(int x=4;x<=7;x++)
{
	System.out.println("Entered the x loop\t"+x);
	isPlusSignPresent = driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+m+"]/td["+x+"]/div/text/div[1]/div[2]/img[@id='imgMon']")).isDisplayed();//verifying if plus minus sign is present or not

if(isPlusSignPresent)
{
	System.out.println("Entered the if block for  x loop ");

	try {
		System.out.println("Entered the try block for  x loop ");

		System.out.println("123");
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+m+"]/td["+x+"]/div/text/div[1]/div[2]/img[@id='imgMon']"))));
		Thread.sleep(4000);
		Actions actions = new Actions(driver);
	    actions.moveToElement(driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+m+"]/td["+x+"]/div/text/div[1]/div[2]/img[@id='imgMon']"))).click();
	    actions.build().perform();
		//driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+i+"]/td["+k+"]/div/text/div[1]/div[2]/img[@id='imgMon']")).click();
		wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='myform']/table/tbody/tr[2]/td[2]")));
		Select select = new Select(driver.findElement(By.xpath("//*[@id='ddlselectShiftList1']")));
		WebElement option = select.getFirstSelectedOption();
		 ShiftType = option.getText();
		
if(ShiftType.contains("On Call"))
{
		count+=1;
		System.out.println("Shift type is\t"+ShiftType+"\tfor\t"+m+","+x);	
}

driver.findElement(By.xpath("//*[@id='myModal']/div/div/div[1]/button")).click();
	} 
	catch (Exception e ) {
				
		System.out.println("Entered the catch block for  k loop ");
	}
}
else
{
	System.out.println("Entered the else block for  k loop ");

	System.out.println("abc");
	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+m+"]/td["+x+"]/div/text/div[1]/div[2]/img[@id='imgMon']")));
	Thread.sleep(500);
	wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+m+"]/td["+x+"]/div/text/div[1]/div[2]/img[@id='imgMon']"))));
	Thread.sleep(4000);
	System.out.println("abcd");
	Actions actions = new Actions(driver);
    actions.moveToElement(driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+m+"]/td["+x+"]/div/text/div[1]/div[2]/img[@id='imgMon']"))).click();
    actions.build().perform();
	//driver.findElement(By.xpath("//*[@id='gvgriddetails']/tbody/tr["+i+"]/td["+k+"]/div/text/div[1]/div[2]/img[@id='imgMon']")).click();
	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.xpath("//*[@id='myform']/table/tbody/tr[2]/td[2]")));

	wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='myform']/table/tbody/tr[2]/td[2]")));
	Select select = new Select(driver.findElement(By.xpath("//*[@id='ddlselectShiftList1']")));
	WebElement option = select.getFirstSelectedOption();
	 ShiftType = option.getText();
	
if(ShiftType.contains("On Call"))
{
	count+=1;
	System.out.println("Shift type is\t"+ShiftType+"\tfor\t"+m+","+x);	
}

driver.findElement(By.xpath("//*[@id='myModal']/div/div/div[1]/button")).click();
	continue;

}
}	

if(count==30)
{
	ShiftTypeIsOnCall=true ;
}
else
{
	ShiftTypeIsOnCall= false;
}
System.out.println("count is\t:"+count);
Assert.assertTrue(ShiftTypeIsOnCall);
logger.log(LogStatus.PASS, "Shift Type is 'ON CALL' for all working days");
}


}
}





