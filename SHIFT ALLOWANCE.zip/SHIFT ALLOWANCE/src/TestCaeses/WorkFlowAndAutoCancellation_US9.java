package TestCaeses;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import HELPER.BrowserFactory;
import HELPER.DB_Operation;
import HELPER.ExcelDataConfig;
import HELPER.Screenshot;
import POM.Home_Page;
import POM.LoginPage;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;



@Listeners(HELPER.TestNGListener.class)
public class WorkFlowAndAutoCancellation_US9 {
	ExtentReports report = new ExtentReports("D:\\Shift Allowance\\AUTOMATION\\US9\\Reports\\WORK FLOW & AUTO-CANCELLATYION.html");    //Creating Object Of class 
	ExtentTest logger;
	String LOCATION_OF_SCREENSHOT="D:\\Shift Allowance\\AUTOMATION\\US9\\SCREENSHOTS\\";

	public  WebDriver driver;   //creating Global Variable
	String xpathmonth=null;
	 String totaldays=null;
	String MonthToBeChecked=null;
	String MonthToBeClicked=null;
	String AdjustedMSAmount=null;String AdjustedASAmount=null;String AdjustedNSAmount=null;String AdjustedOCAAmount=null;String AdjustedOCAHAmount=null;String TotalMSShift=null;String TotalAFShift=null;
	String TotalNSShift=null;String TotalONCShift=null;String TotalONCHShift=null;String TotalAmount=null;
	String StatusID;
	Boolean RequestGeneratedInDB=null;
	Boolean RequestApproved_By_PROJECT_MANAGER_Reflecting_InDB=null;
	Boolean RequestApproved_By_Supervisor_Reflecting_InDB=null;
	Boolean RequestRejected_By_Supervisor_Reflecting_InDB=null;
	Boolean RequestRejected_By_ProjectManager_Reflecting_InDB=null;
	String Supervisor_NTUSERID=null;
	String Manager_NTUSERID=null;
    String FirstMonth;
    String  SecondMonth;
    String ThirdMonth;
   String LogInExcelPath="D:\\Shift Allowance\\AUTOMATION\\US8_AUTOMATION_LOGIN CREDENTIALS_DATA DRIVEN.xlsx";
   DB_Operation DB= new DB_Operation();
   String EmpulseDataPath= "D:\\Shift Allowance\\TEST DATA\\US9_TC4_REGRESSION TESTING_DATA CREATED_EMPULSE ATTENDANCE TABLE.xlsx";
   String ShiftDataPath= "D:\\Shift Allowance\\TEST DATA\\US9_TC4_REGRESSION TESTING_DATA CREATED_SHIFT DETAILS TABLE.xlsx";
	@BeforeTest
	
	    public void CreatingData() throws Exception
	    {
	    	DB.InsertingDataShiftDetails(ShiftDataPath);//INSERTING DATA INTO SHIFTDETAILS TABLE
	    	DB.InsertingDataEmpulseAtt(EmpulseDataPath);//INSERING DATA INTO EMPULSEATTENDANCE TABLE
	    }
    @AfterTest
	    public void DeletingData() throws Exception
	    {
	    	Connection conn=DB.ConnectingToDB();
	    	 ExcelDataConfig excel1= new ExcelDataConfig(EmpulseDataPath);//Using the library designed to read the data i.e executing DATA DRIVEN approach
	 	    
		     PreparedStatement  pstmt3=conn.prepareStatement("DELETE FROM   [ShiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseAttendance]  where EmpID=? and Year =? and Month=? ");
		     pstmt3.setString( 1, excel1.getData(0, 1, 0)); 
		     pstmt3.setString( 2, excel1.getData(0, 1, 22)); 
		     pstmt3.setString( 3, excel1.getData(0, 1, 23));
		     pstmt3.executeUpdate();
		     PreparedStatement pstmt4=conn.prepareStatement("DELETE FROM   [ShiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseShiftDetails]  where EmpID=? and Year =? and Month=? ");
		     pstmt4.setString( 1, excel1.getData(0, 1, 0)); 
		     pstmt4.setString( 2, excel1.getData(0, 1, 22)); 
		     pstmt4.setString( 3, excel1.getData(0, 1, 23));
		     pstmt4.executeUpdate();
		     conn.close();
	    
	    }
	    @BeforeClass
	    public void LastThreeMonths() throws Exception
	    {
	  	  String[] months = new String[]{" ","January","February","March","April","May","June","July","August","September","October","November","December"};
		  Calendar now = Calendar.getInstance();
		  String[] NoOfDaysInMonth = new String[]{"","31","28","31","30","31","30","31","31","30","31","30","31"};

		  ExcelDataConfig excel1= new ExcelDataConfig(EmpulseDataPath);//Using the library designed to read the data i.e executing DATA DRIVEN approach
		  String index=excel1.getData(0, 0, 23) ;
		 int  monthno=Integer.parseInt(index);
		 totaldays=NoOfDaysInMonth[monthno];
		  MonthToBeChecked= months[monthno];
		  System.out.println(months[monthno]);
		  System.out.println(MonthToBeChecked);
		  int month= now.get(Calendar.MONTH) + 1; //Fetching the current month
			if(month>3)
			{    FirstMonth =  months[month-3];
				 SecondMonth =  months[month-2];
				ThirdMonth =  months[month-1];
			}
			
			else if (month==3)
			{
				FirstMonth =  months[12];
				 SecondMonth =  months[1];
				 ThirdMonth =  months[2];
			}
			
			else if (month==2)
			{
				 FirstMonth =  months[11];
				 SecondMonth =  months[12];
				 ThirdMonth =  months[1];
			}
			else if (month==1)
			{
				 FirstMonth =  months[10];
			    SecondMonth =  months[11];
				 ThirdMonth =  months[12];
			}
			if(MonthToBeChecked.equalsIgnoreCase(FirstMonth))
			{
				MonthToBeClicked=FirstMonth;
				xpathmonth="First";
			}
			else if(MonthToBeChecked.equalsIgnoreCase(SecondMonth))
			{
				MonthToBeClicked=SecondMonth;
				xpathmonth="Second";
			}
			else if(MonthToBeChecked.equalsIgnoreCase(ThirdMonth))
			{
				MonthToBeClicked=ThirdMonth;
				xpathmonth="Third";
			}
			else
			{
				System.out.println(MonthToBeChecked+"\tCalendar is not displayed");
				xpathmonth="lol, go find where is the mistake";
				System.out.println(xpathmonth);
			}
	    }
	    
	  
	 
		@BeforeMethod//TestNG methods that are annotated with @BeforeMethod annotation will be run before executing each test method.
		
	    public void setUp( ) throws Exception 
		{
			 driver = BrowserFactory.StartBrowser("IE", "https://shiftallowancesit.fs.capgemini.com");   //Using BrowserFactory tO LAUNCH THE BROWSER
			 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);   //Applying Implicit Wait		   
		}
	
		@AfterMethod   //TestNG methods that are annotated with @AfterMethod annotation will be run after executing each test method.
		public void tearDown(ITestResult result) throws Exception {
			
			
			
			if(ITestResult.FAILURE==result.getStatus())
			{
				String ScrshotPath = Screenshot.CaptureScrShot(driver, LOCATION_OF_SCREENSHOT,result.getName());
				String image= logger.addScreenCapture(ScrshotPath);
				logger.log(LogStatus.FAIL, image);	 
			}
			
			Connection conn=DB.ConnectingToDB();
	    	 ExcelDataConfig excel1= new ExcelDataConfig(EmpulseDataPath);//Using the library designed to read the data i.e executing DATA DRIVEN approach
	 	     PreparedStatement pstmt0=conn.prepareStatement("delete from [ShiftAllowance_SIT].[dbo].[tblShiftAllowanceTransaction] where shiftdetailsid IN(select shiftdetailsid from [ShiftAllowance_SIT].[dbo].[tblshiftrequestdetails] where requestid IN(select requestid  from [ShiftAllowance_SIT].[dbo].[tblshiftrequest] where employeeid=?  and year=? and month=?))" );
	 	     pstmt0.setString( 1, excel1.getData(0, 1, 0)); 
	 	     pstmt0.setString( 2, excel1.getData(0, 1, 22)); 
	 	   pstmt0.setString( 3, excel1.getData(0, 1, 23));
	 	   pstmt0.executeUpdate();
	 	   PreparedStatement pstmt=conn.prepareStatement("delete from [ShiftAllowance_SIT].[dbo].[tblshiftrequestdetails] where requestid IN(select requestid  from [ShiftAllowance_SIT].[dbo].[tblshiftrequest] where employeeid=?  and year=? and month=?) " );
		     pstmt.setString( 1, excel1.getData(0, 1, 0)); 
		     pstmt.setString( 2, excel1.getData(0, 1, 22)); 
		     pstmt.setString( 3, excel1.getData(0, 1, 23));
		     pstmt.executeUpdate();
		     PreparedStatement  pstmt1=conn.prepareStatement("delete from [ShiftAllowance_SIT].[dbo].[tblshiftrequestdetails] where requestid IN(select requestid  from [ShiftAllowance_SIT].[dbo].[tblshiftrequest] where employeeid=?  and year=? and month=?) " );
		     pstmt1.setString( 1, excel1.getData(0, 1, 0)); 
		     pstmt1.setString( 2, excel1.getData(0, 1, 22)); 
		     pstmt1.setString( 3, excel1.getData(0, 1, 23));
		     pstmt1.executeUpdate();
		     PreparedStatement pstmt2=conn.prepareStatement("delete from [ShiftAllowance_SIT].[dbo].[tblshiftrequest] where requestid IN(select requestid  from [ShiftAllowance_SIT].[dbo].[tblshiftrequest] where employeeid=?  and year=? and month=?)");
		     pstmt2.setString( 1, excel1.getData(0, 1, 0)); 
		     pstmt2.setString( 2, excel1.getData(0, 1, 22)); 
		     pstmt2.setString( 3, excel1.getData(0, 1, 23));
		     pstmt2.executeUpdate();
		     conn.close();
	        report.endTest(logger); 
	        report.flush();
	       driver.quit();
		}
		
		@AfterSuite
		public void GenerateReport()
		{
			System.setProperty("webdriver.chrome.driver", "D:\\Selenium Related\\chromedriver.exe");
			WebDriver driver= new ChromeDriver();
			driver.manage().window().maximize();
				driver.get("D:\\Shift Allowance\\AUTOMATION\\US9\\Reports\\WORK FLOW & AUTO-CANCELLATYION.html");
		}
		
		
		 
	@Test(priority=1)
		public void PositiveWorkFlow( ) throws Exception
		{
			 
			
			logger= report.startTest("POSITIVE WORK FLOW OF SHIFT ALLOWANCE");
			logger.log(LogStatus.INFO,"Browser is up and Running");
			LoginPage login = PageFactory.initElements(driver, LoginPage.class);
			ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed by me to read the data i.e executing DATA DRIVEN approach
			String uid= (String) excel.getData(0, 0,0);//storing the username
			String pass=(String) excel.getData(0, 0,1);//storing the password
			login.LogIn(uid, pass);
			logger.log(LogStatus.INFO,"Successfully Logged IN");
			Home_Page home = PageFactory.initElements(driver, Home_Page.class);
			home.Shift();
			logger.log(LogStatus.INFO,"Home Page is up and running");
			Boolean isMonthToBeClickedPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+MonthToBeClicked+"']")).size()!=0;
			Assert.assertTrue(isMonthToBeClickedPresent);
			logger.log(LogStatus.PASS, MonthToBeClicked+"Calendar is Present");
			if(xpathmonth.equalsIgnoreCase("First"))
			{
			driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();
			}
			else if(xpathmonth.equalsIgnoreCase("Second"))
			{
			driver.findElement(By.xpath("//*[@id='SecondMonth']/div/table")).click();
			} 
			else if(xpathmonth.equalsIgnoreCase("Third"))
			{
			driver.findElement(By.xpath("//*[@id='ThirdMonth']/div/table")).click();
			} 
			else{
				System.out.println("Dude You Messed Up");
			}
			
			JavascriptExecutor js = (JavascriptExecutor) driver;
			 js.executeScript("arguments[0].scrollIntoView();",driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[2]/img")) );//scrolling to get STARTDATE field in view of the browser	
			 Thread.sleep(4000);
				WebDriverWait wait=new WebDriverWait(driver, 30);
				wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[2]/img"))));//waiting till field START DATE is clickable
                 Thread.sleep(6000);
                 Boolean StartDateCalendarDisplayed= driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[2]/img")).isDisplayed();//Start DATE Field is displayed or not?
                 Assert.assertTrue(StartDateCalendarDisplayed);
                 WebElement StartDateCalendar = driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[2]/img"));
                js.executeScript("arguments[0].click();", StartDateCalendar);//clicking on the small calendar image in the Field START DATE
		     Thread.sleep(3000);
		   
		int count=0;
		String LastDate=null;
			for(int i=1;i<=6;i++)
			
			{
				for(int j=1;j<=7;j++)
				{
					
				 try {
		                js.executeScript("arguments[0].click();", StartDateCalendar);
						wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='ui-datepicker-div']"))));
					Boolean days= driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr["+i+"]/td["+j+"]")).isDisplayed();
					if(days)
					 {
						 WebElement element1 = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr["+i+"]/td["+j+"]/a"));
					        js.executeScript("arguments[0].click();", element1);
					    count+=1;
					    System.out.println(count);
					   String FirstDate= element1.getText();
					   if(FirstDate.equals("1"))
	    				 {
						   System.out.println("DATE 1 is PRESENT IN (ROW,COL)\t"+i+","+j);
				        	js.executeScript("arguments[0].click();", element1);
				        	break;
	    				 }
					}
					 else
					 {
						 System.out.println("ELEMENT NOT Displayed");
						continue ;
					 }
				} catch (Exception e) {
					continue;
				}
				 if(count==1)
				 {
					 break;
				 }
				}
				 if(count==1)
				 {
					 break;
				 }
				}
			Thread.sleep(5000);
			//logger.log(LogStatus.INFO,"Date 1 is selected");
			 Boolean EndDateCalendarDisplayed= driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[4]/img")).isDisplayed();//End DATE Field IMAGE is displayed or not?
             Assert.assertTrue(EndDateCalendarDisplayed);
             WebElement EndDateCalendar = driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[4]/img"));
            js.executeScript("arguments[0].click();", EndDateCalendar);//clicking on the small calendar image in the Field END DATE
         
			if(driver.findElement(By.xpath("//*[@id='myModalPopUp']/div/div")).isDisplayed())
			  {
			  
			      js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='btnModalpopupOK']")));
			  }
		
         

    	     count=0;
    			for(int i=1;i<=6;i++)
    			
    			{
    				for(int j=1;j<=7;j++)
    				{
    					
    				 try {
    			            js.executeScript("arguments[0].click();", EndDateCalendar);
    						wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='ui-datepicker-div']"))));
    					Boolean days= driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr["+i+"]/td["+j+"]")).isDisplayed();
    					if(days)
    					 {
    						 WebElement element2 = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr["+i+"]/td["+j+"]/a"));
    						 LastDate= element2.getText();
    					        
    					        if(LastDate.equals(totaldays))
    		    				 {
    					        	
        					        System.out.println("LAST DATE OF THE CALENDAR IS\t"+LastDate);
    					        	System.out.println("End Date of Calendar is prsent at (row,col)\t"+i+","+j);
    					        	js.executeScript("arguments[0].click();", element2);
    					        	break;
    		    				 }
    					}
    					 else
    					 {
    						 System.out.println("ELEMENT NOT Displayed");
    						continue ;
    					 }
    				} catch (Exception e) {
    					continue;
    				}
    				 
    				}
    				 
    				}
    			 if(driver.findElement(By.xpath("//*[@id='myModalPopUp']/div/div")).isDisplayed())
    	          {
    	          
    	              js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='btnModalpopupOK']")));//Clicking on the pop up that says end date should be greater than start date
    	          }
    			
    			Select select = new Select(driver.findElement(By.xpath("//*[@id='ddlselectProjectList']")));//selecting Project
    			select.selectByIndex(1);//Selecting the 1st Value from the drop down list of Project
    			Select select1 = new Select(driver.findElement(By.xpath("//*[@id='ddlselectTaskList']")));//selecting Task
    			select1.selectByIndex(1);//Selecting the 1st Value from the drop down list of Task
	              js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='ApplyShiftID']")));//Clicking on ADD button
	              Thread.sleep(2000);
	              js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='btnSubmitGridDetails']")));//clicking on SUBMIT button
	              System.out.println("Submit Button Clicked");
	              Thread.sleep(2000);
	              js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='btnModalpopupSubmitOK']")));//clicking on the first(asking whether do u want to submit request) OK button that comes after clicking SUBMIT button
	              Thread.sleep(2000);
				 wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='myModalPopUp']/div/div"))));
				 Boolean RequestSubmitted= driver.findElement(By.xpath("//label[text()='Shift Details Submitted Successfully.']")).isDisplayed();
				 js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='btnModalpopupOK']")));//clicking on 2nd submit button that comes after clicking submit
				 Thread.sleep(2000);
				 Assert.assertTrue(RequestSubmitted);
				logger.log(LogStatus.PASS,"Request Submitted Successfully");
  
	         Connection conn=DB.ConnectingToDB();
		     PreparedStatement	pstmt=conn.prepareStatement("select * from [ShiftAllowance_SIT].[dbo].[tblShiftAllowanceTransaction]   where ShiftDetailsId IN(select ShiftDetailsId from [ShiftAllowance_SIT].[dbo].[tblshiftrequestdetails] where requestid IN(select requestid from [ShiftAllowance_SIT].[dbo].[tblshiftrequest] where employeeid=? and year =? and month=? )) ");
		     ExcelDataConfig excel1= new ExcelDataConfig(EmpulseDataPath);
		     pstmt.setString( 1, excel1.getData(0, 1, 0)); 
		     pstmt.setString( 2, excel1.getData(0, 1, 22)); 
		     pstmt.setString( 3, excel1.getData(0, 1, 23));
		     ResultSet RsStatusID= pstmt.executeQuery( );
			       	while(RsStatusID.next())
				   	 {
			       		StatusID= RsStatusID.getString("StatusID");
				   	 System.out.println("StatusID is\t"+ StatusID);				   	 
		       	if(StatusID.contains("2"))
		       	{		      
		       		RequestGeneratedInDB=true;
		       	}
				   	 }
		       	System.out.println("Is RequestID Generated in DB:\t"+RequestGeneratedInDB);					
		       	Assert.assertTrue(RequestGeneratedInDB);
				logger.log(LogStatus.PASS,"RequestId Generated Successfully");
				home.Home();
				home.LogOff();
				Thread.sleep(3000);
		          pstmt=conn.prepareStatement("select NTUserID from [ShiftAllowance_SIT].[dbo].[tblEmployeeMaster] where EmployeeID IN( Select SupervisorID from  [ShiftAllowance_SIT].[dbo].[tblEmployeeMaster] where EmployeeID=?)");
		          pstmt.setString( 1, excel1.getData(0, 0, 0));
		          ResultSet Supervisor_NTuserID= pstmt.executeQuery( );
		           
		           while(Supervisor_NTuserID.next())
		           {
		        	   Supervisor_NTUSERID= Supervisor_NTuserID.getString("NTUserID");
		           System.out.println("Supervisor NTUSERID is:\t"+Supervisor_NTUSERID);
		           }
		           login.LogIn(Supervisor_NTUSERID,"123");
	  	  			logger.log(LogStatus.INFO, "Successfully Logged in with Supervisor ID");

		           home.ApprovalBySupervisor();
		           Thread.sleep(5000);
		           List<WebElement> li1 = driver.findElements(By.xpath("//h3[@class='ui-accordion-header ui-corner-top ui-accordion-header-collapsed ui-corner-all ui-state-default ui-accordion-icons']"));
		           for(int i=0;i<3;i++)
		           {
		        	  String text=  li1.get(i).getText();
		        	   if(text.contains(MonthToBeClicked))
		        	   {
				           li1.get(i).click();

		        		   break;
		        	   }
		           }

		           
		       //Finding the Row No Where the employee for which we have raised request is present, as a supervisor might have many employees who have raised request
		           int RownoInSupervisor=0;
		              WebElement table =driver.findElement(By.id("oneMonthsPreviousdetailsGrid"));
		              WebElement tbody=table.findElement(By.tagName("tbody"));
		              List<WebElement> rows=tbody.findElements(By.tagName("tr"));
		              ArrayList<String> ListOdIds=new ArrayList<>();
		              String rowNos="";
		              String Empid=excel1.getData(0, 1, 0);
		              System.out.println("employee id is:\t"+Empid);
		              System.out.println("No of Rows are\t"+rows.size());
		              for(int i=1;i<=rows.size();i++)
		              {
		            	  Boolean Employee = driver.findElements(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+i+"]//a[contains(text(),'("+Empid+")')]")).size()!=0;
		                if(Employee)
		                		{
		                	RownoInSupervisor=i;
		                	System.out.println("The element is present in the row no:\t"+i);
		                	break;
		                }
		                
		               
		                else{
		                	System.out.println("Row not found");
		                }
		            	  }
		            
		            	 
		             
		          	try {
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInSupervisor+"]/td[1]//input[@type='checkbox']")));
						   WebElement Checkbox =  driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInSupervisor+"]/td[1]//input[@type='checkbox']"));
						     js.executeScript("arguments[0].click();", Checkbox);//Ticking the Checkbox
					} catch (Exception e) {
						
						e.getMessage();
						System.out.println(e.getMessage());
					}
		          
		          	PreparedStatement   pstmt1 =conn.prepareStatement("select * from [ShiftAllowance_SIT].[dbo].[tblshiftrequestdetails] where requestid IN(select requestid from [ShiftAllowance_SIT].[dbo].[tblshiftrequest] where employeeid=? AND YEAR =? AND MONTH=? ) ");
		          	pstmt1.setString( 1, excel1.getData(0, 1, 0)); 
		          	pstmt1.setString( 2, excel1.getData(0, 1, 22)); 
		          	pstmt1.setString( 3, excel1.getData(0, 1, 23));
         	       	 ResultSet Verify_Rates_Count_FromDB= pstmt1.executeQuery( );
  			         	while(Verify_Rates_Count_FromDB.next())
  				   	   {
  			         		TotalMSShift= Verify_Rates_Count_FromDB.getString("TotalMSShift");
  				   	    System.out.println("TotalMSShift is\t"+ TotalMSShift);
  				   	AdjustedMSAmount=Verify_Rates_Count_FromDB.getString("AdjustedMSAmount");
				   	    System.out.println("AdjustedMSAmount is\t"+ AdjustedMSAmount);
  				  TotalAFShift= Verify_Rates_Count_FromDB.getString("TotalAFShift");
			   	    System.out.println("TotalAFShift is\t"+ TotalAFShift);
			   	 AdjustedASAmount= Verify_Rates_Count_FromDB.getString("AdjustedASAmount");
			   	    System.out.println("AdjustedASAmount is\t"+ AdjustedASAmount);
			   	 TotalNSShift= Verify_Rates_Count_FromDB.getString("TotalNSShift");
			   	    System.out.println("TotalNSShift is\t"+ TotalNSShift);
			   	 AdjustedNSAmount= Verify_Rates_Count_FromDB.getString("AdjustedNSAmount");
			   	    System.out.println("AdjustedNSAmount is\t"+ AdjustedNSAmount);
			   	 TotalONCShift= Verify_Rates_Count_FromDB.getString("TotalONCShift");
			   	    System.out.println("TotalONCShift is\t"+ TotalONCShift);
			   	 AdjustedOCAAmount= Verify_Rates_Count_FromDB.getString("AdjustedOCAAmount");
			   	    System.out.println("AdjustedOCAAmount is\t"+ AdjustedOCAAmount);
			   	 TotalONCHShift= Verify_Rates_Count_FromDB.getString("TotalONCHShift");
			   	    System.out.println("TotalONCHShift is\t"+ TotalONCHShift); 
			   	 AdjustedOCAHAmount= Verify_Rates_Count_FromDB.getString("AdjustedOCAHAmount");
			   	    System.out.println("TotalONCHShift is\t"+ AdjustedOCAHAmount);  
			   	    TotalAmount= Verify_Rates_Count_FromDB.getString("TotalAmount");
			   	    System.out.println("TotalAmount is\t"+ TotalAmount);  

  				   	   }
  				   	   
  			         	String First_Shift_Count= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInSupervisor+"]/td[6]")).getText();
                        System.out.println(First_Shift_Count);
  			         	AssertJUnit.assertTrue(First_Shift_Count.equals(TotalMSShift));
  	  					logger.log(LogStatus.PASS, "Count for FIRST SHIFT VERIFIED by Supervisor");
                         String First_Shift_Rate= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInSupervisor+"]/td[7]/input")).getAttribute("value");
                         System.out.println(First_Shift_Rate);
   			         	AssertJUnit.assertTrue((First_Shift_Rate+".00").equals(AdjustedMSAmount));
   	  					logger.log(LogStatus.PASS, "RATE for FIRST SHIFT VERIFIED by Supervisor");
                         String Second_Shift_Count= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInSupervisor+"]/td[8]")).getText();
                         System.out.println(Second_Shift_Count);
    			         	AssertJUnit.assertTrue(Second_Shift_Count.equals(TotalAFShift));
      	  					logger.log(LogStatus.PASS, "Count for Second SHIFT VERIFIED by Supervisor");
                         String Second_Shift_Rate= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInSupervisor+"]/td[9]/input")).getAttribute("value");
                         System.out.println(Second_Shift_Rate);
 			         	AssertJUnit.assertTrue((Second_Shift_Rate+".00").equals(AdjustedASAmount));
   	  					logger.log(LogStatus.PASS, "RATE for Second SHIFT VERIFIED by Supervisor");
                         String Third_Shift_Count= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInSupervisor+"]/td[10]")).getText();
                         System.out.println(Third_Shift_Count);
  			         	AssertJUnit.assertTrue(Third_Shift_Count.equals(TotalNSShift));
  	  					logger.log(LogStatus.PASS, "Count for Third SHIFT VERIFIED by Supervisor");
                         String Third_Shift_Rate= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInSupervisor+"]/td[11]/input")).getAttribute("value");
                         System.out.println(Third_Shift_Rate);
   			         	AssertJUnit.assertTrue((Third_Shift_Rate+".00").equals(AdjustedNSAmount));
   	  					logger.log(LogStatus.PASS, "RATE for Third SHIFT VERIFIED by Supervisor");
                         String OnCA_Count= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInSupervisor+"]/td[12]")).getText();
                         System.out.println(OnCA_Count);
    			         	AssertJUnit.assertTrue(OnCA_Count.equals(TotalONCShift));
      	  					logger.log(LogStatus.PASS, "Count for OnCA SHIFT VERIFIED by Supervisor");
                         String OnCA_Rate= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInSupervisor+"]/td[13]/input")).getAttribute("value");
                         System.out.println(OnCA_Rate);
 			         	AssertJUnit.assertTrue((OnCA_Rate+".00").equals(AdjustedOCAAmount));
   	  					logger.log(LogStatus.PASS, "RATE for OnCA SHIFT VERIFIED by Supervisor");
                         String OnCH_Count= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInSupervisor+"]/td[14]")).getText();
                         System.out.println(OnCH_Count);
  			         	AssertJUnit.assertTrue(OnCH_Count.equals(TotalONCHShift));
  	  					logger.log(LogStatus.PASS, "Count for OnCH SHIFT VERIFIED by Supervisor");
                         String OnCH_Rate= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInSupervisor+"]/td[15]/input")).getAttribute("value");
                         System.out.println(OnCH_Rate);
   			         	AssertJUnit.assertTrue((OnCH_Rate+".00").equals(AdjustedOCAHAmount));
   	  					logger.log(LogStatus.PASS, "RATE for OnCH SHIFT VERIFIED by Supervisor");
                        String Total_Shift_Amount= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInSupervisor+"]/td[16]")).getAttribute("innerText");
                        System.out.println(Total_Shift_Amount);
    			         AssertJUnit.assertTrue((Total_Shift_Amount+".00").equals(TotalAmount));
       	  				logger.log(LogStatus.PASS, "Total Amount VERIFIED by Supervisor");
    			         Select Action = new Select(driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInSupervisor+"]//*[@id='ActionType']")));//SELECTING ACTION 
    			         Action.selectByVisibleText("Approve");//SELECTING THE OPTION APPROVE
    			         driver.findElement(By.xpath("//*[@id='btnSubmitShiftUpdates']")).click();//CLICKING SUBMIT BUTTON
    					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='successdialog']/table/tbody/tr/td/input"))));
						 js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='successdialog']/table/tbody/tr/td/input")));
		  	  			logger.log(LogStatus.INFO, "Request Approved by Supervisor");
		  	  		 pstmt=conn.prepareStatement("select * from [ShiftAllowance_SIT].[dbo].[tblShiftAllowanceTransaction]   where ShiftDetailsId IN(select ShiftDetailsId from [ShiftAllowance_SIT].[dbo].[tblshiftrequestdetails] where requestid IN(select requestid from [ShiftAllowance_SIT].[dbo].[tblshiftrequest] where employeeid=? and year =? and month=? )) ");
				     pstmt.setString( 1, excel1.getData(0, 1, 0)); 
				     pstmt.setString( 2, excel1.getData(0, 1, 22)); 
				     pstmt.setString( 3, excel1.getData(0, 1, 23));
				      RsStatusID= pstmt.executeQuery( );
					       	while(RsStatusID.next())
						   	 {
					       		StatusID= RsStatusID.getString("StatusID");
						   	 System.out.println("StatusID is\t"+ StatusID);				   	 
				       	if(StatusID.contains("3"))
				       	{		      
				       		RequestApproved_By_Supervisor_Reflecting_InDB=true;
				       	}
						   	 }
					       	Assert.assertTrue(RequestApproved_By_Supervisor_Reflecting_InDB);
			  	  			logger.log(LogStatus.PASS, "Request Approved by Supervisor and Reflecting in DB");
			  	  		home.Home();
						home.LogOff();
						Thread.sleep(3000);

			  	  		pstmt=conn.prepareStatement("Select * from [ShiftAllowance_SIT].[dbo].[tblEmployeeMaster] where EmployeeID in(select ManagerEmployeeId from [ShiftAllowance_SIT].[dbo].[tblProjectMaster] where ProjectNumber IN (select ProjectNumber from [ShiftAllowance_SIT].[dbo].[tblshiftrequestdetails] where requestid IN(select requestid from [ShiftAllowance_SIT].[dbo].[tblshiftrequest] where employeeid=?  and year=? and month = ? )))");
					     pstmt.setString( 1, excel1.getData(0, 1, 0)); 
					     pstmt.setString( 2, excel1.getData(0, 1, 22)); 
					     pstmt.setString( 3, excel1.getData(0, 1, 23));
					     ResultSet Proj_Manager_NTUSERID= pstmt.executeQuery( );
					     while(Proj_Manager_NTUSERID.next())
					   	 {
					    	 Manager_NTUSERID= Proj_Manager_NTUSERID.getString("NTUserID");
					   	 System.out.println("Proj_Manager_NTUSERID is\t"+ Manager_NTUSERID);
					   	 }
					     
					     login.LogIn(Manager_NTUSERID,"123");
			  	  			logger.log(LogStatus.INFO, "Successfully Logged in with PROJECT MANAGER ID");

					     home.ApprovalByProjectManager();
				           Thread.sleep(5000);

				           List<WebElement> li2 = driver.findElements(By.xpath("//h3[@class='ui-accordion-header ui-corner-top ui-accordion-header-collapsed ui-corner-all ui-state-default ui-accordion-icons']"));
				           for(int i=0;i<3;i++)
				           {
				        	  String text=  li2.get(i).getText();
				        	   if(text.contains(MonthToBeClicked))
				        	   {
						           li2.get(i).click();

				        		   break;
				        	   }
				           }
				           
				           Thread.sleep(5000);
				           
				           //Finding the Row No Where the employee for which we have raised request is present, as a manager might have many employees who have raised request
				           int RownoInManager=0;
							wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("oneMonthsPreviousdetailsGrid")));
							System.out.println("Table found");

				              WebElement table1 =driver.findElement(By.id("oneMonthsPreviousdetailsGrid"));
				              wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("tbody")));
								System.out.println("Body found");
				              WebElement tbody1=table1.findElement(By.tagName("tbody"));
				              
				              try {
								wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("tr")));
									System.out.println("Row found");
							} catch (Exception e1) {
								
								e1.printStackTrace();
								System.out.println(e1.getMessage());
							}
				              List<WebElement> rows1=tbody1.findElements(By.tagName("tr"));
				              ArrayList<String> ListOdIds1=new ArrayList<>();
				              String rowNos1="";
				             
				          
				              System.out.println("No of Rows are\t"+rows1.size());
				              for(int i=1;i<=rows.size();i++)
				              {

				            	  Boolean Employee = driver.findElements(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+i+"]//a[contains(text(),'("+Empid+")')]")).size()!=0;
				                if(Employee)
				                		{
				                	RownoInManager=i;
				                	System.out.println("The element is present in the row no:\t"+i);
				                	break;
				                }
				                
				               
				                else{
				                	System.out.println("Row not found");
				                }
				            	  }
				            
				       	try {
							wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInManager+"]/td[1]//input[@type='checkbox']")));
							   WebElement Checkbox =  driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInManager+"]/td[1]//input[@type='checkbox']"));
							     js.executeScript("arguments[0].click();", Checkbox);
						} catch (Exception e) {
							
							e.getMessage();
							System.out.println(e.getMessage());
						}
				       	
				         pstmt1 =conn.prepareStatement("select * from [ShiftAllowance_SIT].[dbo].[tblshiftrequestdetails] where requestid IN(select requestid from [ShiftAllowance_SIT].[dbo].[tblshiftrequest] where employeeid=? AND YEAR =? AND MONTH=? ) ");
			          	pstmt1.setString( 1, excel1.getData(0, 1, 0)); 
			          	pstmt1.setString( 2, excel1.getData(0, 1, 22)); 
			          	pstmt1.setString( 3, excel1.getData(0, 1, 23));
	         	       Verify_Rates_Count_FromDB= pstmt1.executeQuery( );
	  			         	while(Verify_Rates_Count_FromDB.next())
	  				   	   {
	  			         		TotalMSShift= Verify_Rates_Count_FromDB.getString("TotalMSShift");
	  				   	    System.out.println("TotalMSShift is\t"+ TotalMSShift);
	  				   	AdjustedMSAmount=Verify_Rates_Count_FromDB.getString("AdjustedMSAmount");
					   	    System.out.println("AdjustedMSAmount is\t"+ AdjustedMSAmount);
	  				  TotalAFShift= Verify_Rates_Count_FromDB.getString("TotalAFShift");
				   	    System.out.println("TotalAFShift is\t"+ TotalAFShift);
				   	 AdjustedASAmount= Verify_Rates_Count_FromDB.getString("AdjustedASAmount");
				   	    System.out.println("AdjustedASAmount is\t"+ AdjustedASAmount);
				   	 TotalNSShift= Verify_Rates_Count_FromDB.getString("TotalNSShift");
				   	    System.out.println("TotalNSShift is\t"+ TotalNSShift);
				   	 AdjustedNSAmount= Verify_Rates_Count_FromDB.getString("AdjustedNSAmount");
				   	    System.out.println("AdjustedNSAmount is\t"+ AdjustedNSAmount);
				   	 TotalONCShift= Verify_Rates_Count_FromDB.getString("TotalONCShift");
				   	    System.out.println("TotalONCShift is\t"+ TotalONCShift);
				   	 AdjustedOCAAmount= Verify_Rates_Count_FromDB.getString("AdjustedOCAAmount");
				   	    System.out.println("AdjustedOCAAmount is\t"+ AdjustedOCAAmount);
				   	 TotalONCHShift= Verify_Rates_Count_FromDB.getString("TotalONCHShift");
				   	    System.out.println("TotalONCHShift is\t"+ TotalONCHShift); 
				   	 AdjustedOCAHAmount= Verify_Rates_Count_FromDB.getString("AdjustedOCAHAmount");
				   	    System.out.println("TotalONCHShift is\t"+ AdjustedOCAHAmount);  
				   	    TotalAmount= Verify_Rates_Count_FromDB.getString("TotalAmount");
				   	    System.out.println("TotalAmount is\t"+ TotalAmount);  

	  				   	   }
	  				   	   
	  			         	 First_Shift_Count= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInManager+"]/td[6]")).getText();
	                        System.out.println(First_Shift_Count);
	  			         	AssertJUnit.assertTrue(First_Shift_Count.equals(TotalMSShift));
	  	  					logger.log(LogStatus.PASS, "Count for FIRST SHIFT Verified by PROJECT MANAGER");
	                         First_Shift_Rate= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInManager+"]/td[7]/input")).getAttribute("value");
	                         System.out.println(First_Shift_Rate);
	   			         	AssertJUnit.assertTrue((First_Shift_Rate+".00").equals(AdjustedMSAmount));
	   	  					logger.log(LogStatus.PASS, "RATE for FIRST SHIFT VERIFIED by PROJECT MANAGER");
	                         Second_Shift_Count= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInManager+"]/td[8]")).getText();
	                         System.out.println(Second_Shift_Count);
	    			         	AssertJUnit.assertTrue(Second_Shift_Count.equals(TotalAFShift));
	      	  					logger.log(LogStatus.PASS, "Count for Second SHIFT VERIFIED by PROJECT MANAGER");
	                        Second_Shift_Rate= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInManager+"]/td[9]/input")).getAttribute("value");
	                         System.out.println(Second_Shift_Rate);
	 			         	AssertJUnit.assertTrue((Second_Shift_Rate+".00").equals(AdjustedASAmount));
	   	  					logger.log(LogStatus.PASS, "RATE for Second SHIFT VERIFIED by PROJECT MANAGER");
	                          Third_Shift_Count= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInManager+"]/td[10]")).getText();
	                         System.out.println(Third_Shift_Count);
	  			         	AssertJUnit.assertTrue(Third_Shift_Count.equals(TotalNSShift));
	  	  					logger.log(LogStatus.PASS, "Count for Third SHIFT VERIFIED by PROJECT MANAGER");
	                          Third_Shift_Rate= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInManager+"]/td[11]/input")).getAttribute("value");
	                         System.out.println(Third_Shift_Rate);
	   			         	AssertJUnit.assertTrue((Third_Shift_Rate+".00").equals(AdjustedNSAmount));
	   	  					logger.log(LogStatus.PASS, "RATE for Third SHIFT VERIFIED by PROJECT MANAGER");
	                          OnCA_Count= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInManager+"]/td[12]")).getText();
	                         System.out.println(OnCA_Count);
	    			         	AssertJUnit.assertTrue(OnCA_Count.equals(TotalONCShift));
	      	  					logger.log(LogStatus.PASS, "Count for OnCA SHIFT VERIFIED by PROJECT MANAGER");
	                          OnCA_Rate= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInManager+"]/td[13]/input")).getAttribute("value");
	                         System.out.println(OnCA_Rate);
	 			         	AssertJUnit.assertTrue((OnCA_Rate+".00").equals(AdjustedOCAAmount));
	   	  					logger.log(LogStatus.PASS, "RATE for OnCA SHIFT VERIFIED by PROJECT MANAGER");
	                          OnCH_Count= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInManager+"]/td[14]")).getText();
	                         System.out.println(OnCH_Count);
	  			         	AssertJUnit.assertTrue(OnCH_Count.equals(TotalONCHShift));
	  	  					logger.log(LogStatus.PASS, "Count for OnCH SHIFT VERIFIED by PROJECT MANAGER");
	                         OnCH_Rate= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInManager+"]/td[15]/input")).getAttribute("value");
	                         System.out.println(OnCH_Rate);
	   			         	AssertJUnit.assertTrue((OnCH_Rate+".00").equals(AdjustedOCAHAmount));
	   	  					logger.log(LogStatus.PASS, "RATE for OnCH SHIFT VERIFIED by PROJECT MANAGER");
	                         Total_Shift_Amount= driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInManager+"]/td[16]")).getAttribute("innerText");
	                        System.out.println(Total_Shift_Amount);
	    			         AssertJUnit.assertTrue((Total_Shift_Amount+".00").equals(TotalAmount));
	       	  				logger.log(LogStatus.PASS, "Total Amount VERIFIED by PROJECT MANAGER");
	    			          Action = new Select(driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInManager+"]//*[@id='ActionType']")));
	    			         Action.selectByVisibleText("Approve");
	    			         driver.findElement(By.xpath("//*[@id='btnSubmitShiftUpdates']")).click();
	    					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='successdialog']/table/tbody/tr/td/input"))));
							 js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='successdialog']/table/tbody/tr/td/input")));
			  	  			logger.log(LogStatus.INFO, "Request Approved by PROJECT MANAGER");
			  	  		 pstmt=conn.prepareStatement("select * from [ShiftAllowance_SIT].[dbo].[tblShiftAllowanceTransaction]   where ShiftDetailsId IN(select ShiftDetailsId from [ShiftAllowance_SIT].[dbo].[tblshiftrequestdetails] where requestid IN(select requestid from [ShiftAllowance_SIT].[dbo].[tblshiftrequest] where employeeid=? and year =? and month=? )) ");
					     pstmt.setString( 1, excel1.getData(0, 1, 0)); 
					     pstmt.setString( 2, excel1.getData(0, 1, 22)); 
					     pstmt.setString( 3, excel1.getData(0, 1, 23));
					      RsStatusID= pstmt.executeQuery( );
						       	while(RsStatusID.next())
							   	 {
						       		StatusID= RsStatusID.getString("StatusID");
							   	 System.out.println("StatusID is\t"+ StatusID);				   	 
					       	if(StatusID.contains("9"))
					       	{		      
					       		RequestApproved_By_PROJECT_MANAGER_Reflecting_InDB=true;
					       	}
							   	 }
						       	Assert.assertTrue(RequestApproved_By_PROJECT_MANAGER_Reflecting_InDB);
				  	  			logger.log(LogStatus.PASS, "Request Approved by PROJECT MANAGER and Reflecting in DB");
				  	  		home.Home();
							home.LogOff();
			  	  			logger.log(LogStatus.INFO, "Request Approved and Closed");

			  	  			logger.log(LogStatus.INFO, "Positive Work Flow of SHIFT ALLOWANCE APPLICATION is working absolutely fine.");
	 


				
		}
		
		
		@Test(priority=2)
		public void ProjectManager_RejectesReuest_ApprovedBySupervisor() throws Exception 
		{
			
			logger= report.startTest("Project Manager Can Rejec the Request for Shift Allowance Even Though Approved By Supervisor");
			logger.log(LogStatus.INFO,"Browser is up and Running");
			LoginPage login = PageFactory.initElements(driver, LoginPage.class);
			ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed by me to read the data i.e executing DATA DRIVEN approach
			String uid= (String) excel.getData(0, 0,0);//storing the username
			String pass=(String) excel.getData(0, 0,1);//storing the password
			login.LogIn(uid, pass);
			logger.log(LogStatus.INFO,"Successfully Logged IN");
			Home_Page home = PageFactory.initElements(driver, Home_Page.class);
			home.Shift();
			logger.log(LogStatus.INFO,"Home Page is up and running");
			Boolean isMonthToBeClickedPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+MonthToBeClicked+"']")).size()!=0;
			Assert.assertTrue(isMonthToBeClickedPresent);
			logger.log(LogStatus.PASS, MonthToBeClicked+"Calendar is Present");
			if(xpathmonth.equalsIgnoreCase("First"))
			{
			driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();
			}
			else if(xpathmonth.equalsIgnoreCase("Second"))
			{
			driver.findElement(By.xpath("//*[@id='SecondMonth']/div/table")).click();
			} 
			else if(xpathmonth.equalsIgnoreCase("Third"))
			{
			driver.findElement(By.xpath("//*[@id='ThirdMonth']/div/table")).click();
			} 
			else{
				System.out.println("Dude You Messed Up");
			}
			
			JavascriptExecutor js = (JavascriptExecutor) driver;
			 js.executeScript("arguments[0].scrollIntoView();",driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[2]/img")) );//scrolling to get STARTDATE field in view of the browser	
			 Thread.sleep(4000);
				WebDriverWait wait=new WebDriverWait(driver, 30);
				wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[2]/img"))));//waiting till field START DATE is clickable
                 Thread.sleep(6000);
                 Boolean StartDateCalendarDisplayed= driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[2]/img")).isDisplayed();//Start DATE Field is displayed or not?
                 Assert.assertTrue(StartDateCalendarDisplayed);
                 WebElement StartDateCalendar = driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[2]/img"));
                js.executeScript("arguments[0].click();", StartDateCalendar);//clicking on the small calendar image in the Field START DATE
		     Thread.sleep(3000);
		   
		int count=0;
		String LastDate=null;
			for(int i=1;i<=6;i++)
			
			{
				for(int j=1;j<=7;j++)
				{
					
				 try {
		                js.executeScript("arguments[0].click();", StartDateCalendar);
						wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='ui-datepicker-div']"))));
					Boolean days= driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr["+i+"]/td["+j+"]")).isDisplayed();
					if(days)
					 {
						 WebElement element1 = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr["+i+"]/td["+j+"]/a"));
					        js.executeScript("arguments[0].click();", element1);
					    count+=1;
					    System.out.println(count);
					   String FirstDate= element1.getText();
					   if(FirstDate.equals("1"))
	    				 {
						   System.out.println("DATE 1 is PRESENT IN (ROW,COL)\t"+i+","+j);
				        	js.executeScript("arguments[0].click();", element1);
				        	break;
	    				 }
					}
					 else
					 {
						 System.out.println("ELEMENT NOT Displayed");
						continue ;
					 }
				} catch (Exception e) {
					continue;
				}
				 if(count==1)
				 {
					 break;
				 }
				}
				 if(count==1)
				 {
					 break;
				 }
				}
			Thread.sleep(5000);
			//logger.log(LogStatus.INFO,"Date 1 is selected");
			 Boolean EndDateCalendarDisplayed= driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[4]/img")).isDisplayed();//End DATE Field IMAGE is displayed or not?
             Assert.assertTrue(EndDateCalendarDisplayed);
             WebElement EndDateCalendar = driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[4]/img"));
            js.executeScript("arguments[0].click();", EndDateCalendar);//clicking on the small calendar image in the Field END DATE
         
			if(driver.findElement(By.xpath("//*[@id='myModalPopUp']/div/div")).isDisplayed())
			  {
			  
			      js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='btnModalpopupOK']")));
			  }
		
         

    	     count=0;
    			for(int i=1;i<=6;i++)
    			
    			{
    				for(int j=1;j<=7;j++)
    				{
    					
    				 try {
    			            js.executeScript("arguments[0].click();", EndDateCalendar);
    						wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='ui-datepicker-div']"))));
    					Boolean days= driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr["+i+"]/td["+j+"]")).isDisplayed();
    					if(days)
    					 {
    						 WebElement element2 = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr["+i+"]/td["+j+"]/a"));
    						 LastDate= element2.getText();
    					        
    					        if(LastDate.equals(totaldays))
    		    				 {
    					        	
        					        System.out.println("LAST DATE OF THE CALENDAR IS\t"+LastDate);
    					        	System.out.println("End Date of Calendar is prsent at (row,col)\t"+i+","+j);
    					        	js.executeScript("arguments[0].click();", element2);
    					        	break;
    		    				 }
    					}
    					 else
    					 {
    						 System.out.println("ELEMENT NOT Displayed");
    						continue ;
    					 }
    				} catch (Exception e) {
    					continue;
    				}
    				 
    				}
    				 
    				}
    			 if(driver.findElement(By.xpath("//*[@id='myModalPopUp']/div/div")).isDisplayed())
    	          {
    	          
    	              js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='btnModalpopupOK']")));//Clicking on the pop up that says end date should be greater than start date
    	          }
    			
    			Select select = new Select(driver.findElement(By.xpath("//*[@id='ddlselectProjectList']")));//selecting Project
    			select.selectByIndex(1);//Selecting the 1st Value from the drop down list of Project
    			Select select1 = new Select(driver.findElement(By.xpath("//*[@id='ddlselectTaskList']")));//selecting Task
    			select1.selectByIndex(1);//Selecting the 1st Value from the drop down list of Task
	              js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='ApplyShiftID']")));//Clicking on ADD button
	              Thread.sleep(2000);
	              js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='btnSubmitGridDetails']")));//clicking on SUBMIT button
	              System.out.println("Submit Button Clicked");
	              Thread.sleep(2000);
	              js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='btnModalpopupSubmitOK']")));//clicking on the first(asking whether do u want to submit request) OK button that comes after clicking SUBMIT button
	              Thread.sleep(2000);
				 wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='myModalPopUp']/div/div"))));
				 Boolean RequestSubmitted= driver.findElement(By.xpath("//label[text()='Shift Details Submitted Successfully.']")).isDisplayed();
				 js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='btnModalpopupOK']")));//clicking on 2nd submit button that comes after clicking submit
				 Thread.sleep(2000);
				 Assert.assertTrue(RequestSubmitted);
				logger.log(LogStatus.PASS,"Request Submitted Successfully");
  
	         Connection conn=DB.ConnectingToDB();
		     PreparedStatement	pstmt=conn.prepareStatement("select * from [ShiftAllowance_SIT].[dbo].[tblShiftAllowanceTransaction]   where ShiftDetailsId IN(select ShiftDetailsId from [ShiftAllowance_SIT].[dbo].[tblshiftrequestdetails] where requestid IN(select requestid from [ShiftAllowance_SIT].[dbo].[tblshiftrequest] where employeeid=? and year =? and month=? )) ");
		     ExcelDataConfig excel1= new ExcelDataConfig(EmpulseDataPath);
		     pstmt.setString( 1, excel1.getData(0, 1, 0)); 
		     pstmt.setString( 2, excel1.getData(0, 1, 22)); 
		     pstmt.setString( 3, excel1.getData(0, 1, 23));
		     ResultSet RsStatusID= pstmt.executeQuery( );
			       	while(RsStatusID.next())
				   	 {
			       		StatusID= RsStatusID.getString("StatusID");
				   	 System.out.println("StatusID is\t"+ StatusID);				   	 
		       	if(StatusID.contains("2"))
		       	{		      
		       		RequestGeneratedInDB=true;
		       	}
				   	 }
		       	System.out.println("Is RequestID Generated in DB:\t"+RequestGeneratedInDB);					
		       	Assert.assertTrue(RequestGeneratedInDB);
				logger.log(LogStatus.PASS,"RequestId Generated Successfully");
				home.Home();
				home.LogOff();
				Thread.sleep(3000);
		          pstmt=conn.prepareStatement("select NTUserID from [ShiftAllowance_SIT].[dbo].[tblEmployeeMaster] where EmployeeID IN( Select SupervisorID from  [ShiftAllowance_SIT].[dbo].[tblEmployeeMaster] where EmployeeID=?)");
		          pstmt.setString( 1, excel1.getData(0, 0, 0));
		          ResultSet Supervisor_NTuserID= pstmt.executeQuery( );
		           
		           while(Supervisor_NTuserID.next())
		           {
		        	   Supervisor_NTUSERID= Supervisor_NTuserID.getString("NTUserID");
		           System.out.println("Supervisor NTUSERID is:\t"+Supervisor_NTUSERID);
		           }
		           login.LogIn(Supervisor_NTUSERID,"123");
	  	  			logger.log(LogStatus.INFO, "Successfully Logged in with Supervisor ID");

		           home.ApprovalBySupervisor();
		           Thread.sleep(5000);
		           List<WebElement> li1 = driver.findElements(By.xpath("//h3[@class='ui-accordion-header ui-corner-top ui-accordion-header-collapsed ui-corner-all ui-state-default ui-accordion-icons']"));
		           for(int i=0;i<3;i++)
		           {
		        	  String text=  li1.get(i).getText();
		        	   if(text.contains(MonthToBeClicked))
		        	   {
				           li1.get(i).click();

		        		   break;
		        	   }
		           }

		           
		       //Finding the Row No Where the employee for which we have raised request is present, as a supervisor might have many employees who have raised request
		           int RownoInSupervisor=0;
		              WebElement table =driver.findElement(By.id("oneMonthsPreviousdetailsGrid"));
		              WebElement tbody=table.findElement(By.tagName("tbody"));
		              List<WebElement> rows=tbody.findElements(By.tagName("tr"));
		              ArrayList<String> ListOdIds=new ArrayList<>();
		              String rowNos="";
		              String Empid=excel1.getData(0, 1, 0);
		              System.out.println("employee id is:\t"+Empid);
		              System.out.println("No of Rows are\t"+rows.size());
		              for(int i=1;i<=rows.size();i++)
		              {
		            	  Boolean Employee = driver.findElements(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+i+"]//a[contains(text(),'("+Empid+")')]")).size()!=0;
		                if(Employee)
		                		{
		                	RownoInSupervisor=i;
		                	System.out.println("The element is present in the row no:\t"+i);
		                	break;
		                }
		                
		               
		                else{
		                	System.out.println("Row not found");
		                }
		            	  }
		            
		            	 
		             
		          	try {
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInSupervisor+"]/td[1]//input[@type='checkbox']")));
						   WebElement Checkbox =  driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInSupervisor+"]/td[1]//input[@type='checkbox']"));
						     js.executeScript("arguments[0].click();", Checkbox);//Ticking the Checkbox
					} catch (Exception e) {
						
						e.getMessage();
						System.out.println(e.getMessage());
					}
		          	 Select Action = new Select(driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInSupervisor+"]//*[@id='ActionType']")));//SELECTING ACTION 
			         Action.selectByVisibleText("Approve");//SELECTING THE OPTION APPROVE
			         driver.findElement(By.xpath("//*[@id='btnSubmitShiftUpdates']")).click();//CLICKING SUBMIT BUTTON
					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='successdialog']/table/tbody/tr/td/input"))));
					 js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='successdialog']/table/tbody/tr/td/input")));
	  	  			logger.log(LogStatus.INFO, "Request Approved by Supervisor");
	  	  		 pstmt=conn.prepareStatement("select * from [ShiftAllowance_SIT].[dbo].[tblShiftAllowanceTransaction]   where ShiftDetailsId IN(select ShiftDetailsId from [ShiftAllowance_SIT].[dbo].[tblshiftrequestdetails] where requestid IN(select requestid from [ShiftAllowance_SIT].[dbo].[tblshiftrequest] where employeeid=? and year =? and month=? )) ");
			     pstmt.setString( 1, excel1.getData(0, 1, 0)); 
			     pstmt.setString( 2, excel1.getData(0, 1, 22)); 
			     pstmt.setString( 3, excel1.getData(0, 1, 23));
			      RsStatusID= pstmt.executeQuery( );
				       	while(RsStatusID.next())
					   	 {
				       		StatusID= RsStatusID.getString("StatusID");
					   	 System.out.println("StatusID is\t"+ StatusID);				   	 
			       	if(StatusID.contains("3"))
			       	{		      
			       		RequestApproved_By_Supervisor_Reflecting_InDB=true;
			       	}
					   	 }
				       	Assert.assertTrue(RequestApproved_By_Supervisor_Reflecting_InDB);
		  	  			logger.log(LogStatus.PASS, "Request Approved by Supervisor and Reflecting in DB");
		  	  		home.Home();
					home.LogOff();
					Thread.sleep(3000);

		  	  		pstmt=conn.prepareStatement("Select * from [ShiftAllowance_SIT].[dbo].[tblEmployeeMaster] where EmployeeID in(select ManagerEmployeeId from [ShiftAllowance_SIT].[dbo].[tblProjectMaster] where ProjectNumber IN (select ProjectNumber from [ShiftAllowance_SIT].[dbo].[tblshiftrequestdetails] where requestid IN(select requestid from [ShiftAllowance_SIT].[dbo].[tblshiftrequest] where employeeid=?  and year=? and month = ? )))");
				     pstmt.setString( 1, excel1.getData(0, 1, 0)); 
				     pstmt.setString( 2, excel1.getData(0, 1, 22)); 
				     pstmt.setString( 3, excel1.getData(0, 1, 23));
				     ResultSet Proj_Manager_NTUSERID= pstmt.executeQuery( );
				     while(Proj_Manager_NTUSERID.next())
				   	 {
				    	 Manager_NTUSERID= Proj_Manager_NTUSERID.getString("NTUserID");
				   	 System.out.println("Proj_Manager_NTUSERID is\t"+ Manager_NTUSERID);
				   	 }
				     
				     login.LogIn(Manager_NTUSERID,"123");
		  	  			logger.log(LogStatus.INFO, "Successfully Logged in with PROJECT MANAGER ID");

				     home.ApprovalByProjectManager();
			           Thread.sleep(5000);

			           List<WebElement> li2 = driver.findElements(By.xpath("//h3[@class='ui-accordion-header ui-corner-top ui-accordion-header-collapsed ui-corner-all ui-state-default ui-accordion-icons']"));
			           for(int i=0;i<3;i++)
			           {
			        	  String text=  li2.get(i).getText();
			        	   if(text.contains(MonthToBeClicked))
			        	   {
					           li2.get(i).click();

			        		   break;
			        	   }
			           }
			           
			           Thread.sleep(5000);
			           
			           //Finding the Row No Where the employee for which we have raised request is present, as a manager might have many employees who have raised request
			           int RownoInManager=0;
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("oneMonthsPreviousdetailsGrid")));
						System.out.println("Table found");

			              WebElement table1 =driver.findElement(By.id("oneMonthsPreviousdetailsGrid"));
			              wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("tbody")));
							System.out.println("Body found");
			              WebElement tbody1=table1.findElement(By.tagName("tbody"));
			              
			              try {
							wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("tr")));
								System.out.println("Row found");
						} catch (Exception e1) {
							
							e1.printStackTrace();
							System.out.println(e1.getMessage());
						}
			              List<WebElement> rows1=tbody1.findElements(By.tagName("tr"));
			              ArrayList<String> ListOdIds1=new ArrayList<>();
			              String rowNos1="";
			             
			          
			              System.out.println("No of Rows are\t"+rows1.size());
			              for(int i=1;i<=rows.size();i++)
			              {

			            	  Boolean Employee = driver.findElements(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+i+"]//a[contains(text(),'("+Empid+")')]")).size()!=0;
			                if(Employee)
			                		{
			                	RownoInManager=i;
			                	System.out.println("The element is present in the row no:\t"+i);
			                	break;
			                }
			                
			               
			                else{
			                	System.out.println("Row not found");
			                }
			            	  }
			            
			       	try {
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInManager+"]/td[1]//input[@type='checkbox']")));
						   WebElement Checkbox =  driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInManager+"]/td[1]//input[@type='checkbox']"));
						     js.executeScript("arguments[0].click();", Checkbox);
					} catch (Exception e) {
						
						e.getMessage();
						System.out.println(e.getMessage());
					}
			        Action = new Select(driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInManager+"]//*[@id='ActionType']")));
			         Action.selectByVisibleText("Reject");
			         driver.findElement(By.xpath("//*[@id='btnSubmitShiftUpdates']")).click();
					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='successdialog']/table/tbody/tr/td/input"))));
					 js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='successdialog']/table/tbody/tr/td/input")));
	  	  			logger.log(LogStatus.INFO, "Request Rejected by PROJECT MANAGER");
		          	
	  	  		 pstmt=conn.prepareStatement("select * from [ShiftAllowance_SIT].[dbo].[tblShiftAllowanceTransaction]   where ShiftDetailsId IN(select ShiftDetailsId from [ShiftAllowance_SIT].[dbo].[tblshiftrequestdetails] where requestid IN(select requestid from [ShiftAllowance_SIT].[dbo].[tblshiftrequest] where employeeid=? and year =? and month=? )) ");
			     pstmt.setString( 1, excel1.getData(0, 1, 0)); 
			     pstmt.setString( 2, excel1.getData(0, 1, 22)); 
			     pstmt.setString( 3, excel1.getData(0, 1, 23));
			      RsStatusID= pstmt.executeQuery( );
				       	while(RsStatusID.next())
					   	 {
				       		StatusID= RsStatusID.getString("StatusID");
					   	 System.out.println("StatusID is\t"+ StatusID);				   	 
			       	if(StatusID.contains("6"))
			       	{		      
			       		RequestRejected_By_ProjectManager_Reflecting_InDB=true;
			       	}
					   	 }
				       	Assert.assertTrue(RequestRejected_By_ProjectManager_Reflecting_InDB);
		  	  			logger.log(LogStatus.PASS, "Request Rejected by PROJECT MANAGER and Reflecting in DB");
		  	  		home.Home();
					home.LogOff();
	  	  			logger.log(LogStatus.INFO, "Request Rejected ");


		          	
		}
		
		
		@Test(priority=3)
		public void Supervisor_Rejects_Request() throws Exception 
		{
			
			logger= report.startTest("Supervisor Can Reject the Request for Shift Allowance");
			logger.log(LogStatus.INFO,"Browser is up and Running");
			LoginPage login = PageFactory.initElements(driver, LoginPage.class);
			ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed by me to read the data i.e executing DATA DRIVEN approach
			String uid= (String) excel.getData(0, 0,0);//storing the username
			String pass=(String) excel.getData(0, 0,1);//storing the password
			login.LogIn(uid, pass);
			logger.log(LogStatus.INFO,"Successfully Logged IN");
			Home_Page home = PageFactory.initElements(driver, Home_Page.class);
			home.Shift();
			logger.log(LogStatus.INFO,"Home Page is up and running");
			Boolean isMonthToBeClickedPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+MonthToBeClicked+"']")).size()!=0;
			Assert.assertTrue(isMonthToBeClickedPresent);
			logger.log(LogStatus.PASS, MonthToBeClicked+"Calendar is Present");
			if(xpathmonth.equalsIgnoreCase("First"))
			{
			driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();
			}
			else if(xpathmonth.equalsIgnoreCase("Second"))
			{
			driver.findElement(By.xpath("//*[@id='SecondMonth']/div/table")).click();
			} 
			else if(xpathmonth.equalsIgnoreCase("Third"))
			{
			driver.findElement(By.xpath("//*[@id='ThirdMonth']/div/table")).click();
			} 
			else{
				System.out.println("Dude You Messed Up");
			}
			
			JavascriptExecutor js = (JavascriptExecutor) driver;
			 js.executeScript("arguments[0].scrollIntoView();",driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[2]/img")) );//scrolling to get STARTDATE field in view of the browser	
			 Thread.sleep(4000);
				WebDriverWait wait=new WebDriverWait(driver, 30);
				wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[2]/img"))));//waiting till field START DATE is clickable
                 Thread.sleep(6000);
                 Boolean StartDateCalendarDisplayed= driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[2]/img")).isDisplayed();//Start DATE Field is displayed or not?
                 Assert.assertTrue(StartDateCalendarDisplayed);
                 WebElement StartDateCalendar = driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[2]/img"));
                js.executeScript("arguments[0].click();", StartDateCalendar);//clicking on the small calendar image in the Field START DATE
		     Thread.sleep(3000);
		   
		int count=0;
		String LastDate=null;
			for(int i=1;i<=6;i++)
			
			{
				for(int j=1;j<=7;j++)
				{
					
				 try {
		                js.executeScript("arguments[0].click();", StartDateCalendar);
						wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='ui-datepicker-div']"))));
					Boolean days= driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr["+i+"]/td["+j+"]")).isDisplayed();
					if(days)
					 {
						 WebElement element1 = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr["+i+"]/td["+j+"]/a"));
					        js.executeScript("arguments[0].click();", element1);
					    count+=1;
					    System.out.println(count);
					   String FirstDate= element1.getText();
					   if(FirstDate.equals("1"))
	    				 {
						   System.out.println("DATE 1 is PRESENT IN (ROW,COL)\t"+i+","+j);
				        	js.executeScript("arguments[0].click();", element1);
				        	break;
	    				 }
					}
					 else
					 {
						 System.out.println("ELEMENT NOT Displayed");
						continue ;
					 }
				} catch (Exception e) {
					continue;
				}
				 if(count==1)
				 {
					 break;
				 }
				}
				 if(count==1)
				 {
					 break;
				 }
				}
			Thread.sleep(5000);
			//logger.log(LogStatus.INFO,"Date 1 is selected");
			 Boolean EndDateCalendarDisplayed= driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[4]/img")).isDisplayed();//End DATE Field IMAGE is displayed or not?
             Assert.assertTrue(EndDateCalendarDisplayed);
             WebElement EndDateCalendar = driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[4]/img"));
            js.executeScript("arguments[0].click();", EndDateCalendar);//clicking on the small calendar image in the Field END DATE
         
			if(driver.findElement(By.xpath("//*[@id='myModalPopUp']/div/div")).isDisplayed())
			  {
			  
			      js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='btnModalpopupOK']")));
			  }
		
         

    	     count=0;
    			for(int i=1;i<=6;i++)
    			
    			{
    				for(int j=1;j<=7;j++)
    				{
    					
    				 try {
    			            js.executeScript("arguments[0].click();", EndDateCalendar);
    						wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='ui-datepicker-div']"))));
    					Boolean days= driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr["+i+"]/td["+j+"]")).isDisplayed();
    					if(days)
    					 {
    						 WebElement element2 = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr["+i+"]/td["+j+"]/a"));
    						 LastDate= element2.getText();
    					        
    					        if(LastDate.equals(totaldays))
    		    				 {
    					        	
        					        System.out.println("LAST DATE OF THE CALENDAR IS\t"+LastDate);
    					        	System.out.println("End Date of Calendar is prsent at (row,col)\t"+i+","+j);
    					        	js.executeScript("arguments[0].click();", element2);
    					        	break;
    		    				 }
    					}
    					 else
    					 {
    						 System.out.println("ELEMENT NOT Displayed");
    						continue ;
    					 }
    				} catch (Exception e) {
    					continue;
    				}
    				 
    				}
    				 
    				}
    			 if(driver.findElement(By.xpath("//*[@id='myModalPopUp']/div/div")).isDisplayed())
    	          {
    	          
    	              js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='btnModalpopupOK']")));//Clicking on the pop up that says end date should be greater than start date
    	          }
    			
    			Select select = new Select(driver.findElement(By.xpath("//*[@id='ddlselectProjectList']")));//selecting Project
    			select.selectByIndex(1);//Selecting the 1st Value from the drop down list of Project
    			Select select1 = new Select(driver.findElement(By.xpath("//*[@id='ddlselectTaskList']")));//selecting Task
    			select1.selectByIndex(1);//Selecting the 1st Value from the drop down list of Task
	              js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='ApplyShiftID']")));//Clicking on ADD button
	              Thread.sleep(2000);
	              js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='btnSubmitGridDetails']")));//clicking on SUBMIT button
	              System.out.println("Submit Button Clicked");
	              Thread.sleep(2000);
	              js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='btnModalpopupSubmitOK']")));//clicking on the first(asking whether do u want to submit request) OK button that comes after clicking SUBMIT button
	              Thread.sleep(2000);
				 wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='myModalPopUp']/div/div"))));
				 Boolean RequestSubmitted= driver.findElement(By.xpath("//label[text()='Shift Details Submitted Successfully.']")).isDisplayed();
				 js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='btnModalpopupOK']")));//clicking on 2nd submit button that comes after clicking submit
				 Thread.sleep(2000);
				 Assert.assertTrue(RequestSubmitted);
				logger.log(LogStatus.PASS,"Request Submitted Successfully");
  
	         Connection conn=DB.ConnectingToDB();
		     PreparedStatement	pstmt=conn.prepareStatement("select * from [ShiftAllowance_SIT].[dbo].[tblShiftAllowanceTransaction]   where ShiftDetailsId IN(select ShiftDetailsId from [ShiftAllowance_SIT].[dbo].[tblshiftrequestdetails] where requestid IN(select requestid from [ShiftAllowance_SIT].[dbo].[tblshiftrequest] where employeeid=? and year =? and month=? )) ");
		     ExcelDataConfig excel1= new ExcelDataConfig(EmpulseDataPath);
		     pstmt.setString( 1, excel1.getData(0, 1, 0)); 
		     pstmt.setString( 2, excel1.getData(0, 1, 22)); 
		     pstmt.setString( 3, excel1.getData(0, 1, 23));
		     ResultSet RsStatusID= pstmt.executeQuery( );
			       	while(RsStatusID.next())
				   	 {
			       		StatusID= RsStatusID.getString("StatusID");
				   	 System.out.println("StatusID is\t"+ StatusID);				   	 
		       	if(StatusID.contains("2"))
		       	{		      
		       		RequestGeneratedInDB=true;
		       	}
				   	 }
		       	System.out.println("Is RequestID Generated in DB:\t"+RequestGeneratedInDB);					
		       	Assert.assertTrue(RequestGeneratedInDB);
				logger.log(LogStatus.PASS,"RequestId Generated Successfully");
				home.Home();
				home.LogOff();
				Thread.sleep(3000);
		          pstmt=conn.prepareStatement("select NTUserID from [ShiftAllowance_SIT].[dbo].[tblEmployeeMaster] where EmployeeID IN( Select SupervisorID from  [ShiftAllowance_SIT].[dbo].[tblEmployeeMaster] where EmployeeID=?)");
		          pstmt.setString( 1, excel1.getData(0, 0, 0));
		          ResultSet Supervisor_NTuserID= pstmt.executeQuery( );
		           
		           while(Supervisor_NTuserID.next())
		           {
		        	   Supervisor_NTUSERID= Supervisor_NTuserID.getString("NTUserID");
		           System.out.println("Supervisor NTUSERID is:\t"+Supervisor_NTUSERID);
		           }
		           login.LogIn(Supervisor_NTUSERID,"123");
	  	  			logger.log(LogStatus.INFO, "Successfully Logged in with Supervisor ID");

		           home.ApprovalBySupervisor();
		           Thread.sleep(5000);
		           List<WebElement> li1 = driver.findElements(By.xpath("//h3[@class='ui-accordion-header ui-corner-top ui-accordion-header-collapsed ui-corner-all ui-state-default ui-accordion-icons']"));
		           for(int i=0;i<3;i++)
		           {
		        	  String text=  li1.get(i).getText();
		        	   if(text.contains(MonthToBeClicked))
		        	   {
				           li1.get(i).click();

		        		   break;
		        	   }
		           }

		           
		       //Finding the Row No Where the employee for which we have raised request is present, as a supervisor might have many employees who have raised request
		           int RownoInSupervisor=0;
		              WebElement table =driver.findElement(By.id("oneMonthsPreviousdetailsGrid"));
		              WebElement tbody=table.findElement(By.tagName("tbody"));
		              List<WebElement> rows=tbody.findElements(By.tagName("tr"));
		              ArrayList<String> ListOdIds=new ArrayList<>();
		              String rowNos="";
		              String Empid=excel1.getData(0, 1, 0);
		              System.out.println("employee id is:\t"+Empid);
		              System.out.println("No of Rows are\t"+rows.size());
		              for(int i=1;i<=rows.size();i++)
		              {
		            	  Boolean Employee = driver.findElements(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+i+"]//a[contains(text(),'("+Empid+")')]")).size()!=0;
		                if(Employee)
		                		{
		                	RownoInSupervisor=i;
		                	System.out.println("The element is present in the row no:\t"+i);
		                	break;
		                }
		                
		               
		                else{
		                	System.out.println("Row not found");
		                }
		            	  }
		            
		            	 
		             
		          	try {
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInSupervisor+"]/td[1]//input[@type='checkbox']")));
						   WebElement Checkbox =  driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInSupervisor+"]/td[1]//input[@type='checkbox']"));
						     js.executeScript("arguments[0].click();", Checkbox);//Ticking the Checkbox
					} catch (Exception e) {
						
						e.getMessage();
						System.out.println(e.getMessage());
					}
		          	 Select Action = new Select(driver.findElement(By.xpath("//*[@id='oneMonthsPreviousdetailsGrid']/tbody/tr["+RownoInSupervisor+"]//*[@id='ActionType']")));//SELECTING ACTION 
			         Action.selectByVisibleText("Reject");//SELECTING THE OPTION APPROVE
			         driver.findElement(By.xpath("//*[@id='btnSubmitShiftUpdates']")).click();//CLICKING SUBMIT BUTTON
					wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='successdialog']/table/tbody/tr/td/input"))));
					 js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='successdialog']/table/tbody/tr/td/input")));
	  	  			logger.log(LogStatus.INFO, "Request Rejected by Supervisor");
	  	  		 pstmt=conn.prepareStatement("select * from [ShiftAllowance_SIT].[dbo].[tblShiftAllowanceTransaction]   where ShiftDetailsId IN(select ShiftDetailsId from [ShiftAllowance_SIT].[dbo].[tblshiftrequestdetails] where requestid IN(select requestid from [ShiftAllowance_SIT].[dbo].[tblshiftrequest] where employeeid=? and year =? and month=? )) ");
			     pstmt.setString( 1, excel1.getData(0, 1, 0)); 
			     pstmt.setString( 2, excel1.getData(0, 1, 22)); 
			     pstmt.setString( 3, excel1.getData(0, 1, 23));
			      RsStatusID= pstmt.executeQuery( );
				       	while(RsStatusID.next())
					   	 {
				       		StatusID= RsStatusID.getString("StatusID");
					   	 System.out.println("StatusID is\t"+ StatusID);				   	 
			       	if(StatusID.contains("4"))
			       	{		      
			       		RequestRejected_By_Supervisor_Reflecting_InDB=true;
			       	}
					   	 }
				       	Assert.assertTrue(RequestRejected_By_Supervisor_Reflecting_InDB);
		  	  		home.Home();
					home.LogOff();
	  	  			logger.log(LogStatus.PASS, "Request Rejected by Supervisor and Reflecting in DB");

		}
		
		@Test(priority=4)
		public void AutoCancel_RequestSubmitted_ShiftUpdated_By_Supervisor() throws Exception
		{

			logger= report.startTest("Auto-Cancellation Mail is triggered or not when supervisor updates the shift after the request is successfully raised by employee");
			logger.log(LogStatus.INFO,"Browser is up and Running");
			LoginPage login = PageFactory.initElements(driver, LoginPage.class);
			ExcelDataConfig excel= new ExcelDataConfig(LogInExcelPath);//Using the library designed by me to read the data i.e executing DATA DRIVEN approach
			String uid= (String) excel.getData(0, 0,0);//storing the username
			String pass=(String) excel.getData(0, 0,1);//storing the password
			login.LogIn(uid, pass);
			logger.log(LogStatus.INFO,"Successfully Logged IN");
			Home_Page home = PageFactory.initElements(driver, Home_Page.class);
			home.Shift();
			logger.log(LogStatus.INFO,"Home Page is up and running");
			Boolean isMonthToBeClickedPresent = driver.findElements(By.xpath("//span [@class='ui-datepicker-month'][text()='"+MonthToBeClicked+"']")).size()!=0;
			Assert.assertTrue(isMonthToBeClickedPresent);
			logger.log(LogStatus.PASS, MonthToBeClicked+"Calendar is Present");
			if(xpathmonth.equalsIgnoreCase("First"))
			{
			driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();
			}
			else if(xpathmonth.equalsIgnoreCase("Second"))
			{
			driver.findElement(By.xpath("//*[@id='SecondMonth']/div/table")).click();
			} 
			else if(xpathmonth.equalsIgnoreCase("Third"))
			{
			driver.findElement(By.xpath("//*[@id='ThirdMonth']/div/table")).click();
			} 
			else{
				System.out.println("Dude You Messed Up");
			}
			
			JavascriptExecutor js = (JavascriptExecutor) driver;
			 js.executeScript("arguments[0].scrollIntoView();",driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[2]/img")) );//scrolling to get STARTDATE field in view of the browser	
			 Thread.sleep(4000);
				WebDriverWait wait=new WebDriverWait(driver, 30);
				wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[2]/img"))));//waiting till field START DATE is clickable
                 Thread.sleep(6000);
                 Boolean StartDateCalendarDisplayed= driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[2]/img")).isDisplayed();//Start DATE Field is displayed or not?
                 Assert.assertTrue(StartDateCalendarDisplayed);
                 WebElement StartDateCalendar = driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[2]/img"));
                js.executeScript("arguments[0].click();", StartDateCalendar);//clicking on the small calendar image in the Field START DATE
		     Thread.sleep(3000);
		   
		int count=0;
		String LastDate=null;
			for(int i=1;i<=6;i++)
			
			{
				for(int j=1;j<=7;j++)
				{
					
				 try {
		                js.executeScript("arguments[0].click();", StartDateCalendar);
						wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='ui-datepicker-div']"))));
					Boolean days= driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr["+i+"]/td["+j+"]")).isDisplayed();
					if(days)
					 {
						 WebElement element1 = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr["+i+"]/td["+j+"]/a"));
					        js.executeScript("arguments[0].click();", element1);
					    count+=1;
					    System.out.println(count);
					   String FirstDate= element1.getText();
					   if(FirstDate.equals("1"))
	    				 {
						   System.out.println("DATE 1 is PRESENT IN (ROW,COL)\t"+i+","+j);
				        	js.executeScript("arguments[0].click();", element1);
				        	break;
	    				 }
					}
					 else
					 {
						 System.out.println("ELEMENT NOT Displayed");
						continue ;
					 }
				} catch (Exception e) {
					continue;
				}
				 if(count==1)
				 {
					 break;
				 }
				}
				 if(count==1)
				 {
					 break;
				 }
				}
			Thread.sleep(5000);
			//logger.log(LogStatus.INFO,"Date 1 is selected");
			 Boolean EndDateCalendarDisplayed= driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[4]/img")).isDisplayed();//End DATE Field IMAGE is displayed or not?
             Assert.assertTrue(EndDateCalendarDisplayed);
             WebElement EndDateCalendar = driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[4]/img"));
            js.executeScript("arguments[0].click();", EndDateCalendar);//clicking on the small calendar image in the Field END DATE
         
			if(driver.findElement(By.xpath("//*[@id='myModalPopUp']/div/div")).isDisplayed())
			  {
			  
			      js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='btnModalpopupOK']")));
			  }
		
         

    	     count=0;
    			for(int i=1;i<=6;i++)
    			
    			{
    				for(int j=1;j<=7;j++)
    				{
    					
    				 try {
    			            js.executeScript("arguments[0].click();", EndDateCalendar);
    						wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='ui-datepicker-div']"))));
    					Boolean days= driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr["+i+"]/td["+j+"]")).isDisplayed();
    					if(days)
    					 {
    						 WebElement element2 = driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr["+i+"]/td["+j+"]/a"));
    						 LastDate= element2.getText();
    					        
    					        if(LastDate.equals(totaldays))
    		    				 {
    					        	
        					        System.out.println("LAST DATE OF THE CALENDAR IS\t"+LastDate);
    					        	System.out.println("End Date of Calendar is prsent at (row,col)\t"+i+","+j);
    					        	js.executeScript("arguments[0].click();", element2);
    					        	break;
    		    				 }
    					}
    					 else
    					 {
    						 System.out.println("ELEMENT NOT Displayed");
    						continue ;
    					 }
    				} catch (Exception e) {
    					continue;
    				}
    				 
    				}
    				 
    				}
    			 if(driver.findElement(By.xpath("//*[@id='myModalPopUp']/div/div")).isDisplayed())
    	          {
    	          
    	              js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='btnModalpopupOK']")));//Clicking on the pop up that says end date should be greater than start date
    	          }
    			
    			Select select = new Select(driver.findElement(By.xpath("//*[@id='ddlselectProjectList']")));//selecting Project
    			select.selectByIndex(1);//Selecting the 1st Value from the drop down list of Project
    			Select select1 = new Select(driver.findElement(By.xpath("//*[@id='ddlselectTaskList']")));//selecting Task
    			select1.selectByIndex(1);//Selecting the 1st Value from the drop down list of Task
	              js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='ApplyShiftID']")));//Clicking on ADD button
	              Thread.sleep(2000);
	              js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='btnSubmitGridDetails']")));//clicking on SUBMIT button
	              System.out.println("Submit Button Clicked");
	              Thread.sleep(2000);
	              js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='btnModalpopupSubmitOK']")));//clicking on the first(asking whether do u want to submit request) OK button that comes after clicking SUBMIT button
	              Thread.sleep(2000);
				 wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id='myModalPopUp']/div/div"))));
				 Boolean RequestSubmitted= driver.findElement(By.xpath("//label[text()='Shift Details Submitted Successfully.']")).isDisplayed();
				 js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//*[@id='btnModalpopupOK']")));//clicking on 2nd submit button that comes after clicking submit
				 Thread.sleep(2000);
				 Assert.assertTrue(RequestSubmitted);
				logger.log(LogStatus.PASS,"Request Submitted Successfully");
  
	         Connection conn=DB.ConnectingToDB();
		     PreparedStatement	pstmt=conn.prepareStatement("select * from [ShiftAllowance_SIT].[dbo].[tblShiftAllowanceTransaction]   where ShiftDetailsId IN(select ShiftDetailsId from [ShiftAllowance_SIT].[dbo].[tblshiftrequestdetails] where requestid IN(select requestid from [ShiftAllowance_SIT].[dbo].[tblshiftrequest] where employeeid=? and year =? and month=? )) ");
		     ExcelDataConfig excel1= new ExcelDataConfig(EmpulseDataPath);
		     pstmt.setString( 1, excel1.getData(0, 1, 0)); 
		     pstmt.setString( 2, excel1.getData(0, 1, 22)); 
		     pstmt.setString( 3, excel1.getData(0, 1, 23));
		     ResultSet RsStatusID= pstmt.executeQuery( );
			       	while(RsStatusID.next())
				   	 {
			       		StatusID= RsStatusID.getString("StatusID");
				   	 System.out.println("StatusID is\t"+ StatusID);				   	 
		       	if(StatusID.contains("2"))
		       	{		      
		       		RequestGeneratedInDB=true;
		       	}
				   	 }
		       	System.out.println("Is RequestID Generated in DB:\t"+RequestGeneratedInDB);					
		       	Assert.assertTrue(RequestGeneratedInDB);
				logger.log(LogStatus.PASS,"RequestId Generated Successfully");
				
				
				 PreparedStatement	pstmt1=conn.prepareStatement("UPDATE  [ShiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseShiftDetails] SET ShiftID='102',ShiftCode='S1',ShiftName='Second Shift' where EmpID=? and Year =? and Month=? AND Date=?");
				 pstmt1.setString( 1, excel1.getData(0, 1, 0)); 
				 pstmt1.setString( 2, excel1.getData(0, 1, 22)); 
				 pstmt1.setString( 3, excel1.getData(0, 1, 23));
				 pstmt1.setString( 4, excel1.getData(0, 1, 24));
				 pstmt1.executeUpdate();
				 
				 
				 Statement smt = conn.createStatement();
			     smt.executeQuery("exec [ShiftAllowance_SIT].[dbo].uspJobAutoCancelCasesEmpulse");
			     smt.executeQuery("select * from [ShiftAllowance_SIT].[dbo].[tbllogmailnotification]");
			     
			
		}
		
		
		
}

