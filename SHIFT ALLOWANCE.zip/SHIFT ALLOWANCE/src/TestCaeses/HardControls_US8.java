/**
 * 
 */
package TestCaeses;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver.Options;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import HELPER.BrowserFactory;
import HELPER.ExcelDataConfig;
import POM.Home_Page;
import POM.LoginPage;

/**
 * @author ghagarwa
 *
 */
public class HardControls_US8 {
	
	WebDriver driver;
	
	@BeforeMethod//TestNG methods that are annotated with @BeforeMethod annotation will be run before executing each test method.
	public void setUp() throws Exception {
		 driver = BrowserFactory.StartBrowser("Chrome", "https://shiftallowancesit.fs.capgemini.com");//Using BrowserFactory tO LAUNCH THE BROWSER
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);//Applying Implicit Wait
			
	}
	
	/*@AfterMethod//TestNG methods that are annotated with @AfterMethod annotation will be run after executing each test method.
	public void tearDown() {
		
		driver.quit();
         
	}*/
	
	/*@Test(priority=1)
	public void ShiftRequest_NotRaised_ForDay_Highlighted_Orange() throws Exception
	{
		
	 
		LoginPage login = PageFactory.initElements(driver, LoginPage.class);//Using PageFactory to access the Page LoginPage which stores all the element present in that webpage
		ExcelDataConfig excel= new ExcelDataConfig("D:\\Shift Allowance\\TEST DATA\\US8_AUTOMATION_LOGIN CREDENTIALS_DATA DRIVEN");//Using the library designed by me to read the data i.e executing DATA DRIVEN approach
		String uid= excel.getData(0, 0,0);//storing the username
		String pass=excel.getData(0, 0,1);//storing the password
		 
		
		login.LogIn(uid, pass);//using "uid" and "pass" as a parametre for the function
		
		Home_Page home = PageFactory.initElements(driver, Home_Page.class);
		
		home.Shift();
		Assert.assertTrue(driver.findElements(By.xpath("//*[@id='ThirdMonth']/div/table")).size()!=0);//Verifying OCTOBER calendar is present, because we have created data required for our scenario on 17th october
		
		driver.findElement(By.xpath("//*[@id='ThirdMonth']/div/table")).click();//clicking on october calendar
		
		String ExpectedColour = "#FF7F50";//hexcode of orange color, picked up from HTML code
		
		String color = driver.findElement(By.xpath("XPATH OF 17th OCTOBER")).getCssValue("background-color");// Provide the xpath of 17th october
		
		String ActualColour = Color.fromString(color).asHex();
		
		 Assert.assertTrue(ActualColour.equalsIgnoreCase(ExpectedColour));//verifying 17th october background colour is orange
		
		Assert.assertFalse(driver.findElements(By.xpath("XPATH OF + SIGN OF 17TH OCTOBER")).size()!=0);//Verifying + sign is not present on 17th october may be the xpath:   //*[@id='gvgriddetails']/tbody/tr[1]/td[4]/div/text/div[1]/div[2]
		
		
	}*/

	
	/*@Test(priority=2)
	public void ShiftRequest_NotRaised_ForDays_Highlighted_Orange() throws Exception
	{
	
		LoginPage login = PageFactory.initElements(driver, LoginPage.class);//Using PageFactory to access the Page LoginPage which stores all the element present in that webpage
		ExcelDataConfig excel= new ExcelDataConfig("D:\\Shift Allowance\\TEST DATA\\US8_AUTOMATION_LOGIN CREDENTIALS_DATA DRIVEN");//Using the library designed by me to read the data i.e executing DATA DRIVEN approach
		String uid= excel.getData(0, 1,0);//storing the username
		String pass=excel.getData(0, 1,1);//storing the password
		 
		
		login.LogIn(uid, pass);//using "uid" and "pass" as a parametre for the function
		
		Home_Page home = PageFactory.initElements(driver, Home_Page.class);
		
		home.Shift();
		Assert.assertTrue(driver.findElements(By.xpath("//*[@id='ThirdMonth']/div/table")).size()!=0);//Verifying OCTOBER calendar is present, because we have created data required for our scenario on 17th october
		
		driver.findElement(By.xpath("//*[@id='ThirdMonth']/div/table")).click();//clicking on october calendar
		
		String ExpectedColour = "#FF7F50";//hexcode of orange color, picked up from HTML code
		
		String color = driver.findElement(By.xpath("XPATH OF 17th OCTOBER")).getCssValue("background-color");// Provide the xpath of 17th october
		
		String ActualColour = Color.fromString(color).asHex();
		
		 Assert.assertTrue(ActualColour.equalsIgnoreCase(ExpectedColour));//verifying 17th october background colour is orange
		
		Assert.assertFalse(driver.findElements(By.xpath("XPATH OF + SIGN OF 17TH OCTOBER")).size()!=0);//Verifying + sign is not present on 17th october may be the xpath:   //*[@id='gvgriddetails']/tbody/tr[1]/td[4]/div/text/div[1]/div[2]
		Assert.assertFalse(driver.findElements(By.xpath("XPATH OF + SIGN OF 18TH OCTOBER")).size()!=0);//Verifying + sign is not present on 17th october may be the xpath:   //*[@id='gvgriddetails']/tbody/tr[1]/td[4]/div/text/div[1]/div[2]
		Assert.assertFalse(driver.findElements(By.xpath("XPATH OF + SIGN OF 19TH OCTOBER")).size()!=0);//Verifying + sign is not present on 17th october may be the xpath:   //*[@id='gvgriddetails']/tbody/tr[1]/td[4]/div/text/div[1]/div[2]

		
	}*/

	@Test(priority=12)
	public void RequestSubmitted_TC4() throws Exception
	{

		LoginPage login = PageFactory.initElements(driver, LoginPage.class);//Using PageFactory to access the Page LoginPage which stores all the element present in that webpage
		//ExcelDataConfig excel= new ExcelDataConfig("D:\\Shift Allowance\\TEST DATA\\US8_AUTOMATION_LOGIN CREDENTIALS_DATA DRIVEN");//Using the library designed by me to read the data i.e executing DATA DRIVEN approach
		//String uid= excel.getData(0, 3,0);//storing the username
		//String pass=excel.getData(0, 3,1);//storing the password
		 
		
		login.LogIn("sdevekar", "123");//using "uid" and "pass" as a parametre for the function
		
		Home_Page home = PageFactory.initElements(driver, Home_Page.class);
		
		home.Shift();
		
		Thread.sleep(4000);
		Boolean isAugPresent= driver.findElements(By.xpath("//*[@id='FirstMonth']/div/table")).size()!=0;
		Assert.assertTrue(isAugPresent);//Verifying OCTOBER calendar is present, because we have created data required for our scenario on 17th october
		//System.out.println("abc");
		 driver.findElement(By.xpath("//*[@id='FirstMonth']/div/table")).click();//clicking on August  calendar
		
		 Thread.sleep(2000);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 Actions actions = new Actions(driver);
		 js.executeScript("arguments[0].scrollIntoView();",driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[2]/img")) );	
		 actions.moveToElement(driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[2]/img"))).click();//Clicking on start date calendar image
	     Thread.sleep(1000);
	     
		 
		 System.out.println("abcd");
		List <WebElement> StartDate = driver.findElements(By.xpath("//div[@id='ui-datepicker-div']/table/tbody/tr[2]/td"));//storing all the data of START DATE TABLE
		
		int NoOfData= StartDate.size();// Getting the size of webelemnt
		System.out.println(NoOfData);
	
		for(int i=0;i<NoOfData;i++){
			 actions.moveToElement(driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[2]/img"))).click();//Clicking on start date calendar image

			List <WebElement> StartDate1 = driver.findElements(By.xpath("//div[@id='ui-datepicker-div']/table/tbody/tr[2]/td"));//storing all the data of START DATE TABLE
		 String date = StartDate1.get(i).getText(); 
		 
			//System.out.println(StartDate.get(i).getText());
			if(date.equals("1"))
			{
				
				System.out.println("abcdef");
				 //actions.moveToElement(driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[2]/img"))).click();//Clicking on start date calendar image
				 actions.moveToElement(driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[2]/img"))).click();//Clicking on start date calendar image

				StartDate1.get(i).click();
				System.out.println("abcdefg");
				break;
				
			}
			
			
			
		}
		
		
		
		
		
		/*Actions actions = new Actions(driver);
		//*[@id="ui-datepicker-div"]/table/tbody/tr[3]/td[6]/a
		actions.moveToElement(driver.findElement(By.xpath("XPATH OF FIELD START DATE"))).click();
		actions.build().perform();
		//*[@id="bulkinsert"]/div[2]/table/tbody/tr[4]/td[4]/img
		Only if the above statement does not work*/
		//*[@id="ddlselectProjectList"]
		
		
	}
/*
	//driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[1]/td[4]/a")).click();//clicking on 1st aug
	
	System.out.println("123");
	actions.moveToElement(driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[4]/img"))).click();
	//driver.findElement(By.xpath("//*[@id='bulkinsert']/div[2]/table/tbody/tr[4]/td[4]/img")).click();
	System.out.println("123456");
	actions.moveToElement(driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[5]/td[6]/a"))).click();
	//driver.findElement(By.xpath("//*[@id='ui-datepicker-div']/table/tbody/tr[5]/td[6]/a")).click();
	System.out.println("1234");
	//driver.findElement(By.xpath("//*[@id='ddlselectProjectList']")).click();
	
	Select Project = new Select(driver.findElement(By.id("ddlselectProjectList")));
	Project.selectByIndex(1);
	System.out.println("1234789");
	Select Task = new Select(driver.findElement(By.id("ddlselectTaskList")));
	Task.selectByIndex(1);
	System.out.println("1234987");
	driver.findElement(By.id("ApplyShiftID")).click();
	actions.moveToElement(driver.findElement(By.id("btnSubmitGridDetails"))).click();
	System.out.println("0");
	//actions.build().perform();
	//driver.findElement(By.id("btnSubmitGridDetails")).click();
	Thread.sleep(3000);
	actions.moveToElement(driver.findElement(By.xpath("//*[@id='btnModalpopupSubmitOK']"))).click();
	//driver.switchTo().frame(1).findElement(By.xpath("//*[@id='btnModalpopupSubmitOK']")).click();
     System.out.println("00");
	
	//driver.switchTo().frame(2);
	System.out.println("000");
	driver.switchTo().frame(2);
	Boolean isMessagePresent= driver.findElement(By.xpath("//*[text='The rostered shift timings for 2 Aug does not match with Empulse Time-in & time-out timings, Please regularize your attendance']")).isDisplayed();
	actions.build().perform();

	
	Assert.assertTrue(isMessagePresent);
	
	*/

}
