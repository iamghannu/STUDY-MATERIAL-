package HELPER;

/**
 * @author ghagarwa
 *To Read Data from excel sheet
 */


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
//import org.apache.commons.compress.compressors.deflate64.Deflate64CompressorInputStream;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ExcelDataConfig {

	XSSFWorkbook wb;   //Class XSSFWorkbook is used to read the whole excel sheet
	XSSFSheet Sheet1;
  //Class XSSFSheet is used to read the sheets of the excel sheet
	
	public ExcelDataConfig(String ExcelPath) throws Exception
	{
		try {
			
			File fis = new File(ExcelPath);
			FileInputStream src = new FileInputStream (fis);
		    wb= new XSSFWorkbook(src);
		
		} 
		catch (Exception e) {
			
			System.out.println(e.getMessage());
		
	}
	}
	
	public int NoOfRowa(int SheetNo)
	{
		XSSFSheet Sheet1 = wb.getSheetAt(SheetNo);
		return(Sheet1.getLastRowNum());
	}
	
	public String getData (int SheetNo, int row, int col )
	{
		
		 Sheet1 = wb.getSheetAt(SheetNo);
		XSSFCell cell = Sheet1.getRow(row).getCell(col);
		DataFormatter formatter = new DataFormatter();
		String data=formatter.formatCellValue(cell);
		System.out.println(data);
		return data;
		
	}
	
	
}
