/**
 * 
 */
package HELPER;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;

/**
 * @author ghagarwa
 *Library to Capture Screenshot
 */
public class Screenshot {

	public static String CaptureScrShot(WebDriver driver,String Location, String ScrshotName)
	{
		
		
		try {
			TakesScreenshot ts = (TakesScreenshot) driver;
			File source = ts.getScreenshotAs(OutputType.FILE);
			String Destination = Location+ScrshotName+".png";
			FileUtils.copyFile(source, new File(Destination));
			
			System.out.println("Screenshot Taken");
			return Destination;
		} catch (Exception e) {
			
			System.out.println("Exception while taking Screenshot"+e.getMessage());
			return e.getMessage();
		} 
		
		
		
		
	}

	
	
	
	
}
