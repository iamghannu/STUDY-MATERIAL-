package HELPER;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import TestCaeses.Apply_Shift_US7;

public class TestNGListener  implements ITestListener {

	@Override
	public void onTestStart(ITestResult result) {
		
		System.out.println("Test Cases Started and Test Case Details are " + result.getName());
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println("Test Cases Passed and Test Case Details are " + result.getName());
		
	}

	@Override
	public void onTestFailure(ITestResult result) {
	
		System.out.println("Test Cases Failed and Test Case Details are " + result.getName());
		//Screenshot.CaptureScrShot(driver, result.getName());
		
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		
		System.out.println("Test Cases Skipped and Test Case Details are " + result.getName());
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		
		System.out.println();
	}

	@Override
	public void onStart(ITestContext context) {
		System.out.println();
	}

	@Override
	public void onFinish(ITestContext context) {
		System.out.println();
		
	}

	
	
	
	
	
}
