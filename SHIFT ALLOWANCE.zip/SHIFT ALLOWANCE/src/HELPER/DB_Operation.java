/**
 * 
 */
package HELPER;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import org.testng.annotations.Test;


/**
 * @author ghagarwa
 *Will be used whenever the need for connectiong and operating SQL arises
 */


public class DB_Operation  {
	
static Connection con;
	
public DB_Operation()
{
	
}  




    public  Connection ConnectingToDB() throws Exception
    {
	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
	System.out.println("Driver Loaded");
	  con = DriverManager.getConnection("jdbc:jtds:sqlserver://10.102.22.136:1433;database=In-PNQ-DSQLDB01/ShiftAllowance_SIT;integratedSecurity=true", "test_ShiftAllowance","test_ShiftAllowance");
    System.out.println("CONNECTION SUCCESS");
    Thread.sleep(1000);
    return(con);
    
   }

	
	public void InsertingDataEmpulseAtt(String EmpulseAttDataPath) throws Exception
	{
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		System.out.println("Driver Loaded");
	    con = DriverManager.getConnection("jdbc:jtds:sqlserver://10.102.22.136:1433;database=In-PNQ-DSQLDB01/ShiftAllowance_SIT;integratedSecurity=true", "test_ShiftAllowance","test_ShiftAllowance");
	    System.out.println("CONNECTION SUCCESS");
	    Thread.sleep(1000);
	
         ExcelDataConfig excel= new ExcelDataConfig(EmpulseAttDataPath);   //Using the library designed by me to read the data i.e executing DATA DRIVEN approach
         int NoOfDays= excel.NoOfRowa(0);
		 String [] st= new String[25];
		for(int i=0;i<=NoOfDays;i++)
		{
		    int index=0;
			PreparedStatement ps= con.prepareStatement("Insert into [ShiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseAttendance](EmpID,EmpName,Org,SBU,BU,SubBU,LocName,SwipeLocation,JobTitName,Entity,PeopleGroup,Billability,DssFunction,Description,InOutDate,PunchInTime,PunchOutTime,ActHrsWorked,AttendanceClassification,ShiftCode,ShiftID,Globalgroupid,Year,Month,Date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ") ;

			for(int j=0;j<25;j++)
			{
				 index=index+1;
				 st[j]= (String) excel.getData(0, i,j); 
				 ps.setString(index, st[j]);
			}
			 ps.executeUpdate();
		}
		con.close();
	}
	
	public void InsertingDataShiftDetails(String ShiftDataPath) throws Exception
	{
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		System.out.println("Driver Loaded");
	    con = DriverManager.getConnection("jdbc:jtds:sqlserver://10.102.22.136:1433;database=In-PNQ-DSQLDB01/ShiftAllowance_SIT;integratedSecurity=true", "test_ShiftAllowance","test_ShiftAllowance");
	    System.out.println("CONNECTION SUCCESS");
	    Thread.sleep(1000);
	
         ExcelDataConfig excel= new ExcelDataConfig(ShiftDataPath);   //Using the library designed by me to read the data i.e executing DATA DRIVEN approach
         int NoOfDays= excel.NoOfRowa(0);
		 String [] st= new String[9];
		for(int i=0;i<=NoOfDays;i++)
		{
		    int index=0;
			PreparedStatement ps= con.prepareStatement("INSERT INTO [ShiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseShiftDetails]([EmpID],[ShiftDate],[ShiftID],[ShiftName],[ShiftCode],[Year],[Month],[Date],[GlobalGroupID])VALUES(?,?,?,?,?,?,?,?,?)") ;

			for(int j=0;j<9;j++)
			{
				 index=index+1;
				 st[j]= (String) excel.getData(0, i,j); 
				 ps.setString(index, st[j]);
			}
			 ps.executeUpdate();
		}
		con.close();
	}
	
	
	    public void ReadingData() throws Exception
		{
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			System.out.println("Driver Loaded");
		    con = DriverManager.getConnection("jdbc:jtds:sqlserver://10.102.22.136:1433;database=In-PNQ-DSQLDB01/ShiftAllowance_SIT;integratedSecurity=true", "test_ShiftAllowance","test_ShiftAllowance");
		    System.out.println("CONNECTION SUCCESS");
		    Thread.sleep(1000);
		
		Statement smt = con.createStatement();
	    ResultSet rs=smt.executeQuery("select * from [ShiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseAttendance] where EmpID='99960_FS' and year =2018 and month=9 ");
			System.out.println(rs);
			while(rs.next())
			{
			String InOutDate= rs.getString("InOutDate");
			System.out.println("Database record is"+ InOutDate);
			}
	        con.close();
	
	}
	    
	    public void DeletingData() throws Exception
		{
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			System.out.println("Driver Loaded");
		    con = DriverManager.getConnection("jdbc:jtds:sqlserver://10.102.22.136:1433;database=In-PNQ-DSQLDB01/ShiftAllowance_SIT;integratedSecurity=true", "test_ShiftAllowance","test_ShiftAllowance");
		    System.out.println("CONNECTION SUCCESS");
		    Thread.sleep(1000);
		
		Statement smt = con.createStatement();
	    ResultSet rs=smt.executeQuery("Delete from [ShiftAllowance_SIT].[dbo].[tbl_Fact_EmpulseAttendance] where EmpID='99981_FS' and year =2018 and month=10 ");
	    con.close();
		
		
		}
	    
	    
}



	
	
	


