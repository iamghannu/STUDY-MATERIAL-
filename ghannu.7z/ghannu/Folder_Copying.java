package ghannu;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.nio.file.Files;


public class Folder_Copying {
	

	    public static void main(String[] args) {

	        File file = new File("D:\\Folder1");
	        //if (!file.exists()) 
	            {if (file.mkdir()) {
	                System.out.println("Folder 1 is created!");
	            } else {
	                System.out.println("Failed to create folder");
	            }
	        }

	        File files = new File("D:\\Folder2");
	        //if (!files.exists()) {
	            {if (files.mkdir()) {
	                System.out.println("Folder 2 is created\n");
	            } else {
	                System.out.println("Failed to create folder\n");
	            }
	        }
	        {
	        	/*Object from;
	        	//Object src;
	        	//Object dest;
				Path src = Path.get("D:\\Folder1\\Book1");
	        	Object to;
				Path dest = Path.get("D:\\Folder2"); 
	        	Files.copy(src, dest);

	        	
	        	/*Object source;
				Object dest;
				Files.copy(source.toPath("D:\\Folder1\\Book1"), dest.toPath("D:\\Folder2"));*/
	       
	        	 File currentFile  = new File("D:\\Folder1\\Book1");
	        	  File targetFile  = new File("D:\\Folder2");  

	        	  // Creating FileOutputStream and FileInputStream variables 
	        	  FileOutputStream fileOutputStream = null;

	        	  FileInputStream fileInputStream = null;
	        	  try {

	        	   // Wrapping the File objects created above within 
	        	   // FileOutputStream and FileInputStream objects
	        	   fileOutputStream = new FileOutputStream(currentFile);
	        	   fileInputStream = new FileInputStream(targetFile);

	        	   // Creating a buffer of byte for storing contents of file
	        	   byte[] buffer = new byte[4096];
	        	   int read;

	        	   // looping the file contents on the current location till
	        	   // it becomes empty
	        	   while ((read = fileInputStream.read(buffer)) != -1) {

	        	    // As each loops terminates the target file gets the 
	        	    // contents of current file in the chunks of buffer 
	        	    fileOutputStream.write(buffer, 0, read);
	        	   }

	        	   // catch blocks for closing of the streams and catching 
	        	   // IOException
	        	  } catch(IOException e) {

	        	   try {
	        	    e.printStackTrace();
	        	    if (fileInputStream != null) {

	        	     fileInputStream.close();     

	        	    }
	        	    if (fileOutputStream != null) {

	        	     fileOutputStream.flush(); 
	        	     fileOutputStream.close();

	        	    }
	        	   }
	        	   catch (IOException e1) {

	        	    e1.printStackTrace();
	        	   }
	        	  }

	        	 }

	        	}

}

