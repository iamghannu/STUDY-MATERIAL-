package ghannu;

import java.util.Scanner;

public class RevNum {

	public static void main(String[] args)
	{
	System.out.println("Input a number between 4 and 6 digits");
	Scanner input= new Scanner(System.in);
	int num= input.nextInt();
	int count=0,newNumber=0;
	int dumNum=num;
	while(dumNum>0)
	{
     dumNum= dumNum/10;
     count++;
	}
	for(int i=count-1; i>=0;i--)
	{
		newNumber= (newNumber +(int)((num%10)*(Math.pow(10,i))));
		System.out.println(i);
		System.out.println("The reversed number"+newNumber);
		num=num/10;
		System.out.println(num);
	}
	System.out.println("The reversed number"+newNumber);
}
}
