package ghannu;

public class ODDNUM {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	  int count=0, num=1;
	  System.out.println("The odd numbers between 1 to 20 are\n");
	  do {
		  System.out.println(num);
		  num=num+2;
		  if(num>20)
		  {
			  count=1;
		  }
		  
	  }while(count==0);

	}

}
