package ghannu;
import java.util.Arrays; 
import java.util.Scanner;
import java.util.Collections;
public class SortArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input= new Scanner (System.in);
		System.out.println("Enter the no of elements\n");
		int numOfEle= input.nextInt();
		String [] ToBeSorted= new String[numOfEle];
		System.out.println("Enter the elements\n");

		for(int i=0;i<numOfEle;i++)
		{
		
			ToBeSorted[i]=input.nextLine();
			
		}
		System.out.println("Enter your choice\n 1.Ascending\n 2.Descending\n");
		int choice=input.nextInt();
		
		if(choice==1)
		{
				
	Arrays.sort(ToBeSorted);
    System.out.println(Arrays.toString(ToBeSorted));
		}
	else if(choice==2)
{
		/*	int index;String Swap;
			for(int i=0; i<numOfEle;i++)
			{
				String Reference= ToBeSorted[i];
				for(int j=i+1;j<numOfEle;j++) 
				{
					if(Integer.parseInt(Reference)<Integer.parseInt(ToBeSorted[j]));
					{
						index=j;
					}
				
				Swap= ToBeSorted[index];
				ToBeSorted[index]=ToBeSorted[i];
				ToBeSorted[i]=Swap;
				
				
			}
		}*/
		 Arrays.sort(ToBeSorted, Collections.reverseOrder());
			System.out.println(Arrays.toString(ToBeSorted));
	}
     
	}
}
