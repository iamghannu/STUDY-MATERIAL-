package ghannu;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Date {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	/*Date myDate = new Date();
		System.out.println(myDate);
		System.out.println(new SimpleDateFormat("MM-dd-yyyy").format(myDate));
		System.out.println(new SimpleDateFormat("yyyy-MM-dd").format(myDate));
		System.out.println(myDate);
		
		
		
		Scanner input= new Scanner();
		Date setMonth = new Date();
		setMonth= input.nextInt();
		input.date.setMonth()..
		date.setYear()..
		date.setDay()..
		date.setlong currentTime = date.getTime();*/
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Date ");
		String date = scanner.next();
		
		LocalDate date1 = LocalDate.parse(date,formatter)		;	
		System.out.println(date1);

		/* SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		java.util.Date date2=null;
		try {
		    //Parsing the String
		    date2 = dateFormat.parse(date);
		} catch (ParseException e) {
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		}
		System.out.println(date2);
		*/
	}

}
